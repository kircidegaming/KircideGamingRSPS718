/* Class267 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import java.awt.Color;

public class Class267 {
	RsBitsBuffer aClass298_Sub53_Sub2_2856;
	Class266 aClass266_2857;

	public Class267(Class266 class266, RsBitsBuffer class298_sub53_sub2) {
		((Class267) this).aClass266_2857 = class266;
		((Class267) this).aClass298_Sub53_Sub2_2856 = class298_sub53_sub2;
	}

	static void method2528(int i) {
		try {
			Class372.aClass323_4052.method3938(-229170373);
			Class165.aClass319_6366.method3882((byte) 16);
			Class385.aClient4141.method2756(159760523);
			Class52_Sub2_Sub1.aCanvas9079.setBackground(Color.black);
			client.anInt8834 = 766301529;
			Class372.aClass323_4052 = Class294.method2825(Class52_Sub2_Sub1.aCanvas9079, 974053514);
			Class165.aClass319_6366 = Class291.method2785(Class52_Sub2_Sub1.aCanvas9079, true, (short) 391);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("lc.fq(").append(')').toString());
		}
	}
}
