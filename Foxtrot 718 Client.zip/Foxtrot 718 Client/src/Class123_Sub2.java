/* Class123_Sub2 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import jaggl.OpenGL;

public class Class123_Sub2 extends Class123 {
	int anInt6951;
	Class_ra_Sub3_Sub1 aClass_ra_Sub3_Sub1_6952;
	Class110_Sub2 aClass110_Sub2_6953;

	public void method1355() {
		if ((((Class_ra_Sub3_Sub1) ((Class123_Sub2) this).aClass_ra_Sub3_Sub1_6952).aClass110_Sub2_9832) != ((Class123_Sub2) this).aClass110_Sub2_6953) {
			if (((Class123_Sub2) this).aClass110_Sub2_6953 == null)
				throw new RuntimeException_Sub1();
			OpenGL.glUseProgram(((Class123_Sub2) this).anInt6951);
			((Class_ra_Sub3_Sub1) ((Class123_Sub2) this).aClass_ra_Sub3_Sub1_6952).aClass110_Sub2_9832 = ((Class123_Sub2) this).aClass110_Sub2_6953;
		}
	}

	void method1353() {
		for (int i = 0; i < method1328(-1467018991); i++)
			((Class110_Sub2) method1369(i, 862535051)).b();
		super.method1353();
	}

	public boolean method1331(Class110 class110) {
		if (((Class123_Sub2) this).aClass110_Sub2_6953 == class110)
			return true;
		if (!class110.method1221())
			return false;
		boolean bool = method1374();
		((Class123_Sub2) this).aClass110_Sub2_6953 = (Class110_Sub2) class110;
		anInt1475 = method1329(class110, -180449856) * -1776466383;
		if (anInt1475 * -33664303 == -1)
			throw new IllegalArgumentException();
		((Class123_Sub2) this).anInt6951 = (((Class110_Sub2) ((Class123_Sub2) this).aClass110_Sub2_6953).anInt8608);
		if (bool) {
			OpenGL.glUseProgram(((Class123_Sub2) this).anInt6951);
			((Class_ra_Sub3_Sub1) ((Class123_Sub2) this).aClass_ra_Sub3_Sub1_6952).aClass110_Sub2_9832 = ((Class123_Sub2) this).aClass110_Sub2_6953;
		}
		return true;
	}

	Class298_Sub31_Sub1 method1367(Class114 class114) {
		return new Class298_Sub31_Sub1_Sub1(this, class114);
	}

	public void method1340() {
		if ((((Class_ra_Sub3_Sub1) ((Class123_Sub2) this).aClass_ra_Sub3_Sub1_6952).aClass110_Sub2_9832) != ((Class123_Sub2) this).aClass110_Sub2_6953) {
			if (((Class123_Sub2) this).aClass110_Sub2_6953 == null)
				throw new RuntimeException_Sub1();
			OpenGL.glUseProgram(((Class123_Sub2) this).anInt6951);
			((Class_ra_Sub3_Sub1) ((Class123_Sub2) this).aClass_ra_Sub3_Sub1_6952).aClass110_Sub2_9832 = ((Class123_Sub2) this).aClass110_Sub2_6953;
		}
	}

	public void method1372() {
		/* empty */
	}

	public boolean method1374() {
		return ((((Class_ra_Sub3_Sub1) ((Class123_Sub2) this).aClass_ra_Sub3_Sub1_6952).aClass110_Sub2_9832) == ((Class123_Sub2) this).aClass110_Sub2_6953);
	}

	public void method1358() {
		/* empty */
	}

	public void method1354() {
		if ((((Class_ra_Sub3_Sub1) ((Class123_Sub2) this).aClass_ra_Sub3_Sub1_6952).aClass110_Sub2_9832) != ((Class123_Sub2) this).aClass110_Sub2_6953) {
			if (((Class123_Sub2) this).aClass110_Sub2_6953 == null)
				throw new RuntimeException_Sub1();
			OpenGL.glUseProgram(((Class123_Sub2) this).anInt6951);
			((Class_ra_Sub3_Sub1) ((Class123_Sub2) this).aClass_ra_Sub3_Sub1_6952).aClass110_Sub2_9832 = ((Class123_Sub2) this).aClass110_Sub2_6953;
		}
	}

	Class110 method1362(Class_ra_Sub3 class_ra_sub3, Class108 class108) {
		return new Class110_Sub2((Class_ra_Sub3_Sub1) class_ra_sub3, this, class108);
	}

	public void method1373() {
		if ((((Class_ra_Sub3_Sub1) ((Class123_Sub2) this).aClass_ra_Sub3_Sub1_6952).aClass110_Sub2_9832) != ((Class123_Sub2) this).aClass110_Sub2_6953) {
			if (((Class123_Sub2) this).aClass110_Sub2_6953 == null)
				throw new RuntimeException_Sub1();
			OpenGL.glUseProgram(((Class123_Sub2) this).anInt6951);
			((Class_ra_Sub3_Sub1) ((Class123_Sub2) this).aClass_ra_Sub3_Sub1_6952).aClass110_Sub2_9832 = ((Class123_Sub2) this).aClass110_Sub2_6953;
		}
	}

	public boolean method1349(Class110 class110) {
		if (((Class123_Sub2) this).aClass110_Sub2_6953 == class110)
			return true;
		if (!class110.method1221())
			return false;
		boolean bool = method1374();
		((Class123_Sub2) this).aClass110_Sub2_6953 = (Class110_Sub2) class110;
		anInt1475 = method1329(class110, -180449856) * -1776466383;
		if (anInt1475 * -33664303 == -1)
			throw new IllegalArgumentException();
		((Class123_Sub2) this).anInt6951 = (((Class110_Sub2) ((Class123_Sub2) this).aClass110_Sub2_6953).anInt8608);
		if (bool) {
			OpenGL.glUseProgram(((Class123_Sub2) this).anInt6951);
			((Class_ra_Sub3_Sub1) ((Class123_Sub2) this).aClass_ra_Sub3_Sub1_6952).aClass110_Sub2_9832 = ((Class123_Sub2) this).aClass110_Sub2_6953;
		}
		return true;
	}

	public void method1357() {
		/* empty */
	}

	public boolean method1375(Class110 class110) {
		if (((Class123_Sub2) this).aClass110_Sub2_6953 == class110)
			return true;
		if (!class110.method1221())
			return false;
		boolean bool = method1374();
		((Class123_Sub2) this).aClass110_Sub2_6953 = (Class110_Sub2) class110;
		anInt1475 = method1329(class110, -180449856) * -1776466383;
		if (anInt1475 * -33664303 == -1)
			throw new IllegalArgumentException();
		((Class123_Sub2) this).anInt6951 = (((Class110_Sub2) ((Class123_Sub2) this).aClass110_Sub2_6953).anInt8608);
		if (bool) {
			OpenGL.glUseProgram(((Class123_Sub2) this).anInt6951);
			((Class_ra_Sub3_Sub1) ((Class123_Sub2) this).aClass_ra_Sub3_Sub1_6952).aClass110_Sub2_9832 = ((Class123_Sub2) this).aClass110_Sub2_6953;
		}
		return true;
	}

	void method1380() {
		for (int i = 0; i < method1328(-1467018991); i++)
			((Class110_Sub2) method1369(i, 1695242016)).b();
		super.method1353();
	}

	public boolean method1371() {
		return ((((Class_ra_Sub3_Sub1) ((Class123_Sub2) this).aClass_ra_Sub3_Sub1_6952).aClass110_Sub2_9832) == ((Class123_Sub2) this).aClass110_Sub2_6953);
	}

	public void method1356() {
		/* empty */
	}

	Class110 method1361(Class_ra_Sub3 class_ra_sub3, Class108 class108) {
		return new Class110_Sub2((Class_ra_Sub3_Sub1) class_ra_sub3, this, class108);
	}

	Class298_Sub31_Sub1 method1364(Class114 class114) {
		return new Class298_Sub31_Sub1_Sub1(this, class114);
	}

	Class123_Sub2(Class_ra_Sub3_Sub1 class_ra_sub3_sub1, Class109 class109) {
		super((Class_ra_Sub3) class_ra_sub3_sub1, class109);
		((Class123_Sub2) this).aClass_ra_Sub3_Sub1_6952 = class_ra_sub3_sub1;
	}

	Class110 method1326(Class_ra_Sub3 class_ra_sub3, Class108 class108) {
		return new Class110_Sub2((Class_ra_Sub3_Sub1) class_ra_sub3, this, class108);
	}

	public boolean method1359() {
		return ((((Class_ra_Sub3_Sub1) ((Class123_Sub2) this).aClass_ra_Sub3_Sub1_6952).aClass110_Sub2_9832) == ((Class123_Sub2) this).aClass110_Sub2_6953);
	}

	public boolean method1376(Class110 class110) {
		if (((Class123_Sub2) this).aClass110_Sub2_6953 == class110)
			return true;
		if (!class110.method1221())
			return false;
		boolean bool = method1374();
		((Class123_Sub2) this).aClass110_Sub2_6953 = (Class110_Sub2) class110;
		anInt1475 = method1329(class110, -180449856) * -1776466383;
		if (anInt1475 * -33664303 == -1)
			throw new IllegalArgumentException();
		((Class123_Sub2) this).anInt6951 = (((Class110_Sub2) ((Class123_Sub2) this).aClass110_Sub2_6953).anInt8608);
		if (bool) {
			OpenGL.glUseProgram(((Class123_Sub2) this).anInt6951);
			((Class_ra_Sub3_Sub1) ((Class123_Sub2) this).aClass_ra_Sub3_Sub1_6952).aClass110_Sub2_9832 = ((Class123_Sub2) this).aClass110_Sub2_6953;
		}
		return true;
	}
}
