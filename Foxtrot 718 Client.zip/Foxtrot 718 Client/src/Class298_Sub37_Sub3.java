/* Class298_Sub37_Sub3 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class298_Sub37_Sub3 extends Class298_Sub37 {
	Class365_Sub1_Sub1_Sub3 aClass365_Sub1_Sub1_Sub3_9578;

	public Class298_Sub37_Sub3(Class365_Sub1_Sub1_Sub3 class365_sub1_sub1_sub3) {
		((Class298_Sub37_Sub3) this).aClass365_Sub1_Sub1_Sub3_9578 = class365_sub1_sub1_sub3;
	}
}
