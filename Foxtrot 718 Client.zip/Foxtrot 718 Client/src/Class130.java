/* Class130 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public abstract class Class130 {
	public Interface9_Impl2 anInterface9_Impl2_1492;
	public int anInt1493;
	public Class233 aClass233_1494 = new Class233();
	protected Class_ra_Sub3 aClass_ra_Sub3_1495;

	public abstract void method1448(Class233 class233);

	public abstract void method1449(int i);

	public abstract void method1450(int i);

	public abstract void method1451();

	public abstract void method1452(Class233 class233);

	public abstract void method1453(int i);

	public abstract void method1454(Class233 class233);

	public abstract void method1455(Class233 class233);

	public abstract void method1456(int i);

	public abstract void method1457(int i);

	public abstract void method1458(Class233 class233);

	Class130(Class_ra_Sub3 class_ra_sub3) {
		aClass_ra_Sub3_1495 = class_ra_sub3;
	}

	public abstract void method1459();

	public abstract void method1460();

	public abstract void method1461();

	public abstract void method1462();
}
