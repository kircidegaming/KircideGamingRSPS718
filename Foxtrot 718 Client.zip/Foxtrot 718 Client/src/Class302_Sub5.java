/* Class302_Sub5 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class302_Sub5 extends Class302 {
	int anInt7659;
	Entity aClass365_Sub1_Sub1_Sub2_7660;
	static Class442 aClass442_7661 = new Class442();
	static int anInt7662 = 0;
	int anInt7663;
	int anInt7664;
	int anInt7665;

	Class302_Sub5() {
		/* empty */
	}
}
