/* Class302_Sub2 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class302_Sub2 extends Class302 {
	short aShort7646;
	int anInt7647 = (int) (Class122.method1319((byte) 1) / 1000L) * -576925551;
	String aString7648;

	Class302_Sub2(String string, int i) {
		((Class302_Sub2) this).aString7648 = string;
		((Class302_Sub2) this).aShort7646 = (short) i;
	}

	public static void method3720(int i, byte i_0_) {
		try {
			Class298_Sub37_Sub12 class298_sub37_sub12 = Class410.method4985(17, (long) i);
			class298_sub37_sub12.method3445(-1772707008);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aan.ak(").append(')').toString());
		}
	}
}
