/* Class185 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class185 {
	short[] aShortArray1896;
	short[] aShortArray1897;
	byte[] aByteArray1898;
	short[] aShortArray1899;

	Class185() {
		/* empty */
	}
}
