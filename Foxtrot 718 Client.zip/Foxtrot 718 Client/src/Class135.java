/* Class135 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import java.io.File;
import java.io.IOException;

public class Class135 implements Interface6 {
	CacheIndex aClass243_6381;
	Class165 aClass165_6382;
	Class57 aClass57_6383;
	public static int anInt6384;

	public boolean method54() {
		return (((Class135) this).aClass243_6381.method2310(791455531 * ((Class135) this).aClass165_6382.anInt6365, -457216440));
	}

	Class135(CacheIndex class243, Class165 class165) {
		((Class135) this).aClass243_6381 = class243;
		((Class135) this).aClass165_6382 = class165;
	}

	public void method58(boolean bool, byte i) {
		try {
			if (bool) {
				int i_0_ = ((Class462.anInt5683 * -2110394505 > client.anInt8794 * 775068819) ? Class462.anInt5683 * -2110394505 : 775068819 * client.anInt8794);
				int i_1_ = ((Class298_Sub40_Sub9.anInt9716 * -1111710645 > -791746413 * client.anInt8803) ? Class298_Sub40_Sub9.anInt9716 * -1111710645 : client.anInt8803 * -791746413);
				int i_2_ = ((Class135) this).aClass57_6383.method271();
				int i_3_ = ((Class135) this).aClass57_6383.method626();
				int i_4_ = 0;
				int i_5_ = i_0_;
				int i_6_ = i_0_ * i_3_ / i_2_;
				int i_7_ = (i_1_ - i_6_) / 2;
				if (i_6_ > i_1_) {
					i_7_ = 0;
					i_6_ = i_1_;
					i_5_ = i_2_ * i_1_ / i_3_;
					i_4_ = (i_0_ - i_5_) / 2;
				}
				((Class135) this).aClass57_6383.method633(i_4_, i_7_, i_5_, i_6_);
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("fl.f(").append(')').toString());
		}
	}

	public boolean method52(int i) {
		try {
			return (((Class135) this).aClass243_6381.method2310(791455531 * ((Class135) this).aClass165_6382.anInt6365, -457216440));
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("fl.b(").append(')').toString());
		}
	}

	public void method55() {
		((Class135) this).aClass57_6383 = Class422_Sub10.method5663(((Class135) this).aClass243_6381, (((Class135) this).aClass165_6382.anInt6365) * 791455531, (byte) -99);
	}

	public void method53(int i) {
		try {
			((Class135) this).aClass57_6383 = Class422_Sub10.method5663(((Class135) this).aClass243_6381, (((Class135) this).aClass165_6382.anInt6365) * 791455531, (byte) -105);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("fl.a(").append(')').toString());
		}
	}

	public boolean method57() {
		return (((Class135) this).aClass243_6381.method2310(791455531 * ((Class135) this).aClass165_6382.anInt6365, -457216440));
	}

	public void method56(boolean bool) {
		if (bool) {
			int i = ((Class462.anInt5683 * -2110394505 > client.anInt8794 * 775068819) ? Class462.anInt5683 * -2110394505 : 775068819 * client.anInt8794);
			int i_8_ = ((Class298_Sub40_Sub9.anInt9716 * -1111710645 > -791746413 * client.anInt8803) ? Class298_Sub40_Sub9.anInt9716 * -1111710645 : client.anInt8803 * -791746413);
			int i_9_ = ((Class135) this).aClass57_6383.method271();
			int i_10_ = ((Class135) this).aClass57_6383.method626();
			int i_11_ = 0;
			int i_12_ = i;
			int i_13_ = i * i_10_ / i_9_;
			int i_14_ = (i_8_ - i_13_) / 2;
			if (i_13_ > i_8_) {
				i_14_ = 0;
				i_13_ = i_8_;
				i_12_ = i_9_ * i_8_ / i_10_;
				i_11_ = (i - i_12_) / 2;
			}
			((Class135) this).aClass57_6383.method633(i_11_, i_14_, i_12_, i_13_);
		}
	}

	public boolean method59() {
		return (((Class135) this).aClass243_6381.method2310(791455531 * ((Class135) this).aClass165_6382.anInt6365, -457216440));
	}

	static final void method1490(IComponentDefinition class105, Class119 class119, ClientScript2 class403, int i) {
		try {
			class105.anInt1217 = (((ClientScript2) class403).anIntArray5244[(((ClientScript2) class403).anInt5239 -= -391880689) * 681479919]) * -1455284437;
			Tradution.method6054(class105, -2049323512);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("fl.gc(").append(')').toString());
		}
	}

	static final void method1491(IComponentDefinition class105, ClientScript2 class403, int i) {
		try {
			int i_15_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			int i_16_ = ((((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]) - 1);
			if (1548853569 * class105.anInt1184 != 6)
				throw new RuntimeException("");
			NPCDefinitions class503 = Class15.aClass507_224.method6269(572201537 * class105.anInt1151, -1577596397);
			if (null == class105.aClass498_1307)
				class105.aClass498_1307 = new Class498(class503, true);
			class105.aClass498_1307.aLong6110 = Class382.method4686(1726426173) * 3177550440302969639L;
			if (i_16_ < 0 || i_16_ >= class503.anIntArray6129.length)
				throw new RuntimeException(new StringBuilder().append("").append(i_16_).toString());
			class105.aClass498_1307.anIntArray6108[i_16_] = i_15_;
			Tradution.method6054(class105, 649700405);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("fl.qt(").append(')').toString());
		}
	}

	static final void method1492(ClientScript2 class403, byte i) {
		try {
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = (null != (Class287.myPlayer.aClass366_10209) && (Class287.myPlayer.aClass366_10209.aBoolean3977)) ? 1 : 0;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("fl.ud(").append(')').toString());
		}
	}

	static byte[] method1493(File file, int i, int i_17_) {
		try {
			byte[] is;
			try {
				byte[] is_18_ = new byte[i];
				Class501.method6231(file, is_18_, i, 1833251010);
				is = is_18_;
			} catch (IOException ioexception) {
				return null;
			}
			return is;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("fl.f(").append(')').toString());
		}
	}

	static final void method1494(Entity class365_sub1_sub1_sub2, boolean bool, int i) {
		try {
			int i_19_ = Class282.aClass282_6543.aByte6542;
			int i_20_ = 0;
			if (-412225079 * class365_sub1_sub1_sub2.anInt10095 > client.anInt8884 * 443738891)
				Class124.method1389(class365_sub1_sub1_sub2, -455530754);
			else if (class365_sub1_sub1_sub2.anInt10103 * 1450943713 >= client.anInt8884 * 443738891)
				Class104.method1103(class365_sub1_sub1_sub2, -1562807680);
			else {
				Class341.method4141(class365_sub1_sub1_sub2, bool, 365613015);
				i_19_ = Class331.anInt3565 * -2143152965;
				i_20_ = Class431.anInt6504 * 236175727;
			}
			Class217 class217 = class365_sub1_sub1_sub2.method4337().aClass217_2599;
			if ((int) class217.aFloat2451 < 512 || (int) class217.aFloat2454 < 512 || ((int) class217.aFloat2451 >= ((client.aClass283_8716.method2629(-2045914503) - 1) * 512)) || ((int) class217.aFloat2454 >= ((client.aClass283_8716.method2630(2070989013) - 1) * 512))) {
				class365_sub1_sub1_sub2.aClass438_10078.method5821(-1, -1660674133);
				for (int i_21_ = 0; i_21_ < class365_sub1_sub1_sub2.currentGraphics.length; i_21_++) {
					class365_sub1_sub1_sub2.currentGraphics[i_21_].id = -1313669563;
					class365_sub1_sub1_sub2.currentGraphics[i_21_].aClass438_569.method5821(-1, -1698848994);
				}
				class365_sub1_sub1_sub2.anIntArray10093 = null;
				class365_sub1_sub1_sub2.anInt10095 = 0;
				class365_sub1_sub1_sub2.anInt10103 = 0;
				i_19_ = Class282.aClass282_6543.aByte6542;
				i_20_ = 0;
				class365_sub1_sub1_sub2.method4341((float) (class365_sub1_sub1_sub2.scenePositionXQueue[0] * 512 + (class365_sub1_sub1_sub2.getSize() * 256)), class217.aFloat2455, (float) (512 * class365_sub1_sub1_sub2.scenePositionYQueue[0] + (class365_sub1_sub1_sub2.getSize() * 256)));
				class365_sub1_sub1_sub2.method4419(229400295);
			}
			if ((Class287.myPlayer == class365_sub1_sub1_sub2) && ((int) class217.aFloat2451 < 6144 || (int) class217.aFloat2454 < 6144 || ((int) class217.aFloat2451 >= (client.aClass283_8716.method2629(-2000317727) - 12) * 512) || ((int) class217.aFloat2454 >= ((client.aClass283_8716.method2630(52673101) - 12) * 512)))) {
				class365_sub1_sub1_sub2.aClass438_10078.method5821(-1, -1994577841);
				for (int i_22_ = 0; i_22_ < class365_sub1_sub1_sub2.currentGraphics.length; i_22_++) {
					class365_sub1_sub1_sub2.currentGraphics[i_22_].id = -1313669563;
					class365_sub1_sub1_sub2.currentGraphics[i_22_].aClass438_569.method5821(-1, -2027122238);
				}
				class365_sub1_sub1_sub2.anIntArray10093 = null;
				class365_sub1_sub1_sub2.anInt10095 = 0;
				class365_sub1_sub1_sub2.anInt10103 = 0;
				i_19_ = Class282.aClass282_6543.aByte6542;
				i_20_ = 0;
				class365_sub1_sub1_sub2.method4341((float) (class365_sub1_sub1_sub2.scenePositionXQueue[0] * 512 + (class365_sub1_sub1_sub2.getSize() * 256)), class217.aFloat2455, (float) (512 * class365_sub1_sub1_sub2.scenePositionYQueue[0] + (class365_sub1_sub1_sub2.getSize() * 256)));
				class365_sub1_sub1_sub2.method4419(1590910009);
			}
			int i_23_ = Class266.method2525(class365_sub1_sub1_sub2, 1199726988);
			Class116.method1270(class365_sub1_sub1_sub2, -1145965611);
			Class298_Sub32_Sub36.method3373(class365_sub1_sub1_sub2, i_19_, i_20_, i_23_, -830154452);
			Class411.method5575(class365_sub1_sub1_sub2, i_19_, 1842586894);
			Class473.method6068(class365_sub1_sub1_sub2, (byte) 27);
			Class218 class218 = Class218.method2019();
			class218.method2032(Class220.method2049(class365_sub1_sub1_sub2.aClass386_10084.method4719((byte) 0)), Class220.method2049(class365_sub1_sub1_sub2.aClass386_10111.method4719((byte) 0)), Class220.method2049(class365_sub1_sub1_sub2.aClass386_10113.method4719((byte) 0)));
			class365_sub1_sub1_sub2.method4346(class218);
			class218.method2029();
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("fl.hn(").append(')').toString());
		}
	}
}
