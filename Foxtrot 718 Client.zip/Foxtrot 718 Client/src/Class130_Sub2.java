/* Class130_Sub2 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class130_Sub2 extends Class130 {
	Class298_Sub31_Sub1 aClass298_Sub31_Sub1_6954;
	Class298_Sub31_Sub1 aClass298_Sub31_Sub1_6955;
	Class233 aClass233_6956 = new Class233();
	Class298_Sub31_Sub1 aClass298_Sub31_Sub1_6957;
	Class298_Sub31_Sub1 aClass298_Sub31_Sub1_6958;
	public static Class57[] aClass57Array6959;
	Class123 aClass123_6960;

	boolean method1464(int i) throws Exception_Sub2 {
		try {
			((Class130_Sub2) this).aClass123_6960 = aClass_ra_Sub3_1495.method5297("Particle");
			((Class130_Sub2) this).aClass298_Sub31_Sub1_6957 = ((Class130_Sub2) this).aClass123_6960.method1360("WVPMatrix", -1445644688);
			((Class130_Sub2) this).aClass298_Sub31_Sub1_6955 = ((Class130_Sub2) this).aClass123_6960.method1360("DiffuseSampler", -471804579);
			((Class130_Sub2) this).aClass298_Sub31_Sub1_6958 = ((Class130_Sub2) this).aClass123_6960.method1360("TexCoordMatrix", 1156990928);
			((Class130_Sub2) this).aClass298_Sub31_Sub1_6954 = ((Class130_Sub2) this).aClass123_6960.method1360("DiffuseColour", -16804392);
			((Class130_Sub2) this).aClass123_6960.method1331(((Class130_Sub2) this).aClass123_6960.method1330(-1437671487));
			return true;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("yx.t(").append(')').toString());
		}
	}

	public void method1452(Class233 class233) {
		try {
			((Class130_Sub2) this).aClass233_6956.method2142(class233);
			((Class130_Sub2) this).aClass233_6956.method2144(aClass_ra_Sub3_1495.aClass233_8251);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("yx.a(").append(')').toString());
		}
	}

	public void method1460() {
		method1465(1482129308);
		aClass_ra_Sub3_1495.method5389();
	}

	public void method1451() {
		try {
			method1465(-351671930);
			aClass_ra_Sub3_1495.method5389();
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("yx.b(").append(')').toString());
		}
	}

	public void method1455(Class233 class233) {
		((Class130_Sub2) this).aClass233_6956.method2142(class233);
		((Class130_Sub2) this).aClass233_6956.method2144(aClass_ra_Sub3_1495.aClass233_8251);
	}

	public void method1454(Class233 class233) {
		((Class130_Sub2) this).aClass233_6956.method2142(class233);
		((Class130_Sub2) this).aClass233_6956.method2144(aClass_ra_Sub3_1495.aClass233_8251);
	}

	void method1465(int i) {
		try {
			((Class130_Sub2) this).aClass123_6960.method1331(((Class130_Sub2) this).aClass123_6960.method1330(-1437671487));
			((Class130_Sub2) this).aClass123_6960.method1340();
			((Class130_Sub2) this).aClass123_6960.method1341(((Class130_Sub2) this).aClass298_Sub31_Sub1_6955, 0, anInterface9_Impl2_1492, -1031634630);
			((Class130_Sub2) this).aClass123_6960.method1368(((Class130_Sub2) this).aClass298_Sub31_Sub1_6957, ((Class130_Sub2) this).aClass233_6956, 600012267);
			((Class130_Sub2) this).aClass123_6960.method1337(((Class130_Sub2) this).aClass298_Sub31_Sub1_6958, aClass233_1494, (byte) 67);
			((Class130_Sub2) this).aClass123_6960.method1363(((Class130_Sub2) this).aClass298_Sub31_Sub1_6954, anInt1493, 1962930050);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("yx.h(").append(')').toString());
		}
	}

	public void method1458(Class233 class233) {
		((Class130_Sub2) this).aClass233_6956.method2142(class233);
		((Class130_Sub2) this).aClass233_6956.method2144(aClass_ra_Sub3_1495.aClass233_8251);
	}

	public void method1457(int i) {
		method1465(-1540213232);
		aClass_ra_Sub3_1495.method5392(Class187.aClass187_1907, 0, 4 * i, 0, 2 * i);
	}

	public void method1449(int i) {
		method1465(451467459);
		aClass_ra_Sub3_1495.method5392(Class187.aClass187_1907, 0, 4 * i, 0, 2 * i);
	}

	public void method1453(int i) {
		method1465(1059849924);
		aClass_ra_Sub3_1495.method5392(Class187.aClass187_1907, 0, 4 * i, 0, 2 * i);
	}

	public void method1459() {
		method1465(303915893);
		aClass_ra_Sub3_1495.method5389();
	}

	public void method1448(Class233 class233) {
		((Class130_Sub2) this).aClass233_6956.method2142(class233);
		((Class130_Sub2) this).aClass233_6956.method2144(aClass_ra_Sub3_1495.aClass233_8251);
	}

	public void method1461() {
		method1465(-268292083);
		aClass_ra_Sub3_1495.method5389();
	}

	public void method1462() {
		method1465(-1254303888);
		aClass_ra_Sub3_1495.method5389();
	}

	public Class130_Sub2(Class_ra_Sub3 class_ra_sub3) throws Exception_Sub2 {
		super(class_ra_sub3);
		method1464(34022465);
	}

	public void method1450(int i) {
		try {
			method1465(33439591);
			aClass_ra_Sub3_1495.method5392(Class187.aClass187_1907, 0, 4 * i, 0, 2 * i);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("yx.f(").append(')').toString());
		}
	}

	public void method1456(int i) {
		method1465(1296040438);
		aClass_ra_Sub3_1495.method5392(Class187.aClass187_1907, 0, 4 * i, 0, 2 * i);
	}
}
