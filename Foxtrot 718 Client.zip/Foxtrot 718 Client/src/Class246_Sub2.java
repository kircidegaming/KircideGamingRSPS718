/* Class246_Sub2 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import jaclib.memory.Source;

public class Class246_Sub2 extends Class246 implements Interface7_Impl1 {
	byte aByte8578;

	public boolean method67(int i, int i_0_, long l) {
		return super.method63(i, i_0_, l);
	}

	Class246_Sub2(Class_ra_Sub3_Sub1 class_ra_sub3_sub1, boolean bool) {
		super(class_ra_sub3_sub1, 34962, bool);
	}

	int method2336() {
		return ((Class246_Sub2) this).aByte8578;
	}

	public boolean method72(int i, int i_1_) {
		((Class246_Sub2) this).aByte8578 = (byte) i_1_;
		super.method113(i);
		return true;
	}

	public boolean method73(int i, int i_2_) {
		((Class246_Sub2) this).aByte8578 = (byte) i_2_;
		super.method113(i);
		return true;
	}

	public void b() {
		super.b();
	}

	public boolean method63(int i, int i_3_, long l) {
		return super.method63(i, i_3_, l);
	}

	public boolean method74(int i, int i_4_, Source source) {
		((Class246_Sub2) this).aByte8578 = (byte) i_4_;
		super.method2334(i, source);
		return true;
	}

	public void method69() {
		super.method69();
	}

	public void d() {
		super.b();
	}

	public void u() {
		super.b();
	}

	public void method66() {
		super.method69();
	}

	public boolean method70(int i, int i_5_) {
		((Class246_Sub2) this).aByte8578 = (byte) i_5_;
		super.method113(i);
		return true;
	}

	public void x() {
		super.b();
	}

	public boolean method71(int i, int i_6_, Source source) {
		((Class246_Sub2) this).aByte8578 = (byte) i_6_;
		super.method2334(i, source);
		return true;
	}

	public int method60() {
		return super.method60();
	}

	public int method65() {
		return super.method60();
	}

	public boolean method61(int i, int i_7_, long l) {
		return super.method63(i, i_7_, l);
	}

	public long method62(int i, int i_8_) {
		return super.method62(i, i_8_);
	}

	public long method68(int i, int i_9_) {
		return super.method62(i, i_9_);
	}

	public int method64() {
		return super.method60();
	}
}
