/* Class170 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public final class Class170 {
	int anInt1737;
	Object anObject1738;

	Class170(Object object, int i) {
		((Class170) this).anObject1738 = object;
		((Class170) this).anInt1737 = i * 533229453;
	}

	static void method1808(int i) {
		try {
			if (Class436.aClass298_Sub37_Sub5_5472 != null) {
				Class436.aClass298_Sub37_Sub5_5472 = null;
				Class227.method2112(805710735 * Class461.anInt5681, Class501.anInt6119 * -1370784315, Class420.anInt5345 * 2054409059, Class389.anInt4166 * -1855216229, (byte) 2);
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ha.z(").append(')').toString());
		}
	}

	static final void method1809(ClientScript2 class403, int i) {
		try {
			Class390 class390 = (((ClientScript2) class403).aBoolean5261 ? ((ClientScript2) class403).aClass390_5247 : ((ClientScript2) class403).aClass390_5246);
			IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = class105.anInt1175 * 1411971043;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ha.pb(").append(')').toString());
		}
	}

	static final void method1810(ClientScript2 class403, byte i) {
		try {
			((ClientScript2) class403).anInt5239 -= -783761378;
			int i_0_ = (((ClientScript2) class403).anIntArray5244[((ClientScript2) class403).anInt5239 * 681479919]);
			int i_1_ = (((ClientScript2) class403).anIntArray5244[1 + ((ClientScript2) class403).anInt5239 * 681479919]);
			((ClientScript2) class403).aClass177_5243.anIntArray1789[i_0_] = i_1_;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ha.adx(").append(')').toString());
		}
	}

	public static void method1811(int i, CacheIndex class243, int i_2_, int i_3_, int i_4_, boolean bool, Class97 class97, byte i_5_) {
		try {
			if (i > 0) {
				Class79.anInt734 = -1262101671;
				Class79.aClass243_744 = class243;
				Class79.anInt745 = i_2_ * -407545223;
				Class79.anInt746 = i_3_ * -956029523;
				Class79.aClass298_Sub19_Sub1_748 = null;
				Class79.anInt739 = i_4_ * -2102749749;
				Class8.aBoolean114 = bool;
				Class298_Sub24_Sub1.anInt9276 = (Class79.aClass298_Sub19_Sub1_737.method2953((byte) -72) / i * 771950311);
				if (-1503744809 * Class298_Sub24_Sub1.anInt9276 < 1)
					Class298_Sub24_Sub1.anInt9276 = 771950311;
				Class313.aClass97_3300 = class97;
			} else {
				if (class97 != null)
					class97.method1037(1056339184);
				Class477.method6096(class243, i_2_, i_3_, i_4_, bool, -1991321667);
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ha.n(").append(')').toString());
		}
	}

	static final void method1812(IComponentDefinition[] class105s, int i, byte i_6_) {
		try {
			for (int i_7_ = 0; i_7_ < class105s.length; i_7_++) {
				IComponentDefinition class105 = class105s[i_7_];
				if (null == class105) {
					if (i_6_ <= 1)
						break;
				} else {
					if (-1215239439 * class105.anInt1144 == 0) {
						if (null != class105.aClass105Array1293)
							method1812(class105.aClass105Array1293, i, (byte) 26);
						Interface class298_sub51 = ((Interface) (client.aClass437_8841.method5812((long) (class105.anInt1142 * -440872681))));
						if (class298_sub51 != null)
							Class82_Sub10.method903((class298_sub51.interfaceId * -1617025021), i, -837806860);
					}
					if (i == 0 && null != class105.anObjectArray1275) {
						Class298_Sub46 class298_sub46 = new Class298_Sub46();
						class298_sub46.aClass105_7525 = class105;
						class298_sub46.anObjectArray7530 = class105.anObjectArray1275;
						Class444.method5889(class298_sub46, (byte) -11);
					}
					if (1 == i && class105.anObjectArray1250 != null) {
						if (class105.anInt1154 * -1309843523 >= 0) {
							IComponentDefinition class105_8_ = Class50.getIComponentDefinitions((class105.anInt1142 * -440872681), (byte) -12);
							if (class105_8_ == null || class105_8_.aClass105Array1292 == null || (-1309843523 * class105.anInt1154 >= class105_8_.aClass105Array1292.length))
								continue;
							if ((class105_8_.aClass105Array1292[-1309843523 * class105.anInt1154]) != class105) {
								if (i_6_ <= 1) {
									/* empty */
								}
								continue;
							}
						}
						Class298_Sub46 class298_sub46 = new Class298_Sub46();
						class298_sub46.aClass105_7525 = class105;
						class298_sub46.anObjectArray7530 = class105.anObjectArray1250;
						Class444.method5889(class298_sub46, (byte) 34);
					}
				}
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ha.lj(").append(')').toString());
		}
	}

	static final void method1813(ClientScript2 class403, byte i) {
		try {
			int i_9_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			if (-1 != i_9_)
				Class119.method1300(i_9_, 2038530463);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ha.anj(").append(')').toString());
		}
	}

	static boolean method1814(Interface19 interface19, Class298_Sub50 class298_sub50, byte i) {
		try {
			return (interface19 != null && interface19.method239(class298_sub50, client.anInterface16Array8688, client.anInt8687 * -1625219821, Class372.aClass323_4052, -622376364));
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ha.i(").append(')').toString());
		}
	}

	static final void method1815(ClientScript2 class403, byte i) {
		try {
			int i_10_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = Class82_Sub5.method882(i_10_, false, (byte) 63);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ha.ui(").append(')').toString());
		}
	}
}
