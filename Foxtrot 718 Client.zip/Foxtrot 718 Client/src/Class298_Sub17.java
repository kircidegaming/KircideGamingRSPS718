/* Class298_Sub17 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public abstract class Class298_Sub17 extends Class298 {
	abstract void method2916(RsByteBuffer class298_sub53);

	abstract void method2917(RsByteBuffer class298_sub53, int i);

	abstract void method2918(Class298_Sub25 class298_sub25, int i);

	abstract void method2919(Class298_Sub25 class298_sub25);

	abstract void method2920(RsByteBuffer class298_sub53);

	Class298_Sub17() {
		/* empty */
	}

	abstract void method2921(Class298_Sub25 class298_sub25);

	abstract void method2922(RsByteBuffer class298_sub53);

	static final void method2923(ClientScript2 class403, byte i) {
		try {
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub5_7572.method5642(74537724) == 2 ? 1 : 0;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("abb.aja(").append(')').toString());
		}
	}
}
