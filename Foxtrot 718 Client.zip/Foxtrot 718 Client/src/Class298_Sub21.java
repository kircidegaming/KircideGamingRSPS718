/* Class298_Sub21 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class298_Sub21 extends Class298 {
	Interface11 anInterface11_7315;

	Class298_Sub21(Interface11 interface11) {
		((Class298_Sub21) this).anInterface11_7315 = interface11;
	}
}
