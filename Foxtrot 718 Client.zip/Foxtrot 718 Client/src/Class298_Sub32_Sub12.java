/* Class298_Sub32_Sub12 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class298_Sub32_Sub12 extends Class298_Sub32 {
	int[] method3209(int i) {
		return Class250.anIntArray2762;
	}

	public Class298_Sub32_Sub12() {
		super(0, true);
	}

	int[] method3210(int i) {
		return Class250.anIntArray2762;
	}

	int[] method3131(int i, int i_0_) {
		try {
			return Class250.anIntArray2762;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aha.i(").append(')').toString());
		}
	}
}
