/* Class336_Sub2 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class336_Sub2 extends Class336 {
	Class424 aClass424_7713;
	int anInt7714;

	public boolean method4089(int i, int i_0_, int i_1_, Class289 class289) {
		return class289.method2742(i_0_, i_1_, i, -1331662251 * toX, toY * 1517720743, ((Class336_Sub2) this).aClass424_7713.method242(694163818), (((Class336_Sub2) this).anInt7714 * -472184325), 1632228208);
	}

	public boolean method4090(int i, int i_2_, int i_3_, Class289 class289, int i_4_) {
		try {
			return class289.method2742(i_2_, i_3_, i, -1331662251 * toX, toY * 1517720743, ((Class336_Sub2) this).aClass424_7713.method242(694163818), (((Class336_Sub2) this).anInt7714 * -472184325), 2085306850);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ace.a(").append(')').toString());
		}
	}

	Class336_Sub2() {
		/* empty */
	}

	public boolean method4091(int i, int i_5_, int i_6_, Class289 class289) {
		return class289.method2742(i_5_, i_6_, i, -1331662251 * toX, toY * 1517720743, ((Class336_Sub2) this).aClass424_7713.method242(694163818), (((Class336_Sub2) this).anInt7714 * -472184325), 1073937483);
	}

	static final void method4096(ClientScript2 class403, int i) {
		try {
			Class390 class390 = (((ClientScript2) class403).aBoolean5261 ? ((ClientScript2) class403).aClass390_5247 : ((ClientScript2) class403).aClass390_5246);
			IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
			Class119 class119 = ((Class390) class390).aClass119_4167;
			Class119.method1298(class105, class119, class403, (byte) 35);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ace.ii(").append(')').toString());
		}
	}

	static void method4097(ClientScript2 class403, short i) {
		try {
			((ClientScript2) class403).anIntArray5244[((ClientScript2) class403).anInt5239 * 681479919 - 1] = Class316.aClass362_3318.method4307((((ClientScript2) class403).anIntArray5244[681479919 * ((ClientScript2) class403).anInt5239 - 1]), 245040087).method4561(Class128.aClass148_6331, 750355235) ? 1 : 0;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ace.w(").append(')').toString());
		}
	}
}
