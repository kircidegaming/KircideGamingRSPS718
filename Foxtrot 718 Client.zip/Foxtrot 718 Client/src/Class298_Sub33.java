/* Class298_Sub33 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class298_Sub33 extends Class298 {
	public long aLong7385;

	public Class298_Sub33(long l) {
		aLong7385 = l * 2132790236050020951L;
	}

	static final void method3396(IComponentDefinition class105, Class119 class119, ClientScript2 class403, int i) {
		try {
			class105.aBoolean1246 = (((ClientScript2) class403).anIntArray5244[(((ClientScript2) class403).anInt5239 -= -391880689) * 681479919]) == 1;
			Tradution.method6054(class105, 1442702884);
			if (-1309843523 * class105.anInt1154 == -1 && !class119.aBoolean1403)
				Class290.method2750(class105.anInt1142 * -440872681, 475870643);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("abr.es(").append(')').toString());
		}
	}
}
