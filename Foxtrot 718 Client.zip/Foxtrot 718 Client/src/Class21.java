/* Class21 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class21 {
	static boolean aBoolean274 = false;
	static int anInt275;
	static int anInt276;
	static int anInt277;

	Class21() throws Throwable {
		throw new Error();
	}

	public static void method364(CacheIndex class243, int i, int i_0_, int i_1_, boolean bool, Class298_Sub19_Sub1 class298_sub19_sub1, int i_2_) {
		try {
			Class477.method6096(class243, i, i_0_, i_1_, bool, -2042287938);
			Class79.aClass298_Sub19_Sub1_748 = class298_sub19_sub1;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("av.b(").append(')').toString());
		}
	}

	static final void method365(IComponentDefinition class105, Class119 class119, boolean bool, int i, ClientScript2 class403, int i_3_) {
		try {
			((ClientScript2) class403).anInt5239 -= -783761378;
			int i_4_ = (((ClientScript2) class403).anIntArray5244[681479919 * ((ClientScript2) class403).anInt5239]);
			int i_5_ = (((ClientScript2) class403).anIntArray5244[681479919 * ((ClientScript2) class403).anInt5239 + 1]);
			if (-1 == class105.anInt1154 * -1309843523 && !class119.aBoolean1403) {
				Class298_Sub50.method3567(-440872681 * class105.anInt1142, 1388671560);
				Class509.method6286(-440872681 * class105.anInt1142, 106150101);
				Class70.method808(class105.anInt1142 * -440872681, 2057190103);
			}
			if (-1 == i_4_) {
				class105.anInt1184 = -1530138943;
				class105.anInt1151 = 1825442367;
				class105.anInt1280 = -643064669;
			} else {
				class105.anInt1280 = i_4_ * 643064669;
				class105.anInt1281 = -160790887 * i_5_;
				class105.aBoolean1213 = bool;
				ItemDefinitions class468 = Class298_Sub32_Sub14.aClass477_9400.getItemDefinitions(i_4_);
				class105.anInt1190 = class468.anInt5714 * 1147619461;
				class105.anInt1262 = -953332053 * class468.anInt5715;
				class105.anInt1192 = 1018171305 * class468.anInt5716;
				class105.anInt1297 = class468.anInt5717 * 216639237;
				class105.anInt1248 = class468.anInt5718 * 2135145581;
				class105.anInt1284 = class468.anInt5713 * -1056736627;
				class105.anInt1201 = i * -625792095;
				if (-692202853 * class105.anInt1221 > 0)
					class105.anInt1284 = (class105.anInt1284 * 237251296 / (class105.anInt1221 * -692202853) * -1066050969);
				else if (1769572195 * class105.anInt1253 > 0)
					class105.anInt1284 = (237251296 * class105.anInt1284 / (class105.anInt1253 * 1769572195) * -1066050969);
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("av.hh(").append(')').toString());
		}
	}

	static final void method366(ClientScript2 class403, int i) {
		try {
			int i_6_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			IComponentDefinition class105 = Class50.getIComponentDefinitions(i_6_, (byte) -54);
			Class119 class119 = Class389.aClass119Array4165[i_6_ >> 16];
			Class317.method3850(class105, class119, class403, -1611318497);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("av.iu(").append(')').toString());
		}
	}

	static final void method367(ClientScript2 class403, int i) {
		try {
			((ClientScript2) class403).anInt5239 -= -783761378;
			int i_7_ = (((ClientScript2) class403).anIntArray5244[((ClientScript2) class403).anInt5239 * 681479919]);
			int i_8_ = (((ClientScript2) class403).anIntArray5244[1 + 681479919 * ((ClientScript2) class403).anInt5239]);
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = (GraphicsToolkit.aClass256_5315.method2441(i_7_, -1634888229).aCharArray9595[i_8_]);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("av.acy(").append(')').toString());
		}
	}

	static final void method368(ClientScript2 class403, int i) {
		try {
			if (Class11.anInt156 * -1111444967 == 2)
				Class11.aBoolean153 = true;
			else if (-1111444967 * Class11.anInt156 == 1)
				Class11.aBoolean154 = true;
			else if (Class11.anInt156 * -1111444967 == 3)
				Class11.aBoolean155 = true;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("av.anf(").append(')').toString());
		}
	}

	static void method369(int i) {
		try {
			Class3.anInt56 = 0;
			Class3.anInt57 = 955770805;
			Class3.anInt62 = 1129029761;
			Class3.anInt54 = 1835291189;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("av.a(").append(')').toString());
		}
	}
}
