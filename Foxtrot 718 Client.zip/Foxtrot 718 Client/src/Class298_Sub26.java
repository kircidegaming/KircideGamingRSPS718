/* Class298_Sub26 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public abstract class Class298_Sub26 extends Class298 {
	int anInt7362;

	Class298_Sub26() {
		/* empty */
	}
}
