/* Class120 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class120 {
	public static Class120 aClass120_1406;
	static Class120 aClass120_1407;
	static Class120 aClass120_1408;
	public static Class120 aClass120_1409;
	public static Class120 aClass120_1410;
	public static Class120 aClass120_1411;
	static Class120 aClass120_1412;
	public static Class120 aClass120_1413;
	public static Class120 aClass120_1414;
	static Class120 aClass120_1415;
	public static Class120 aClass120_1416;
	public static Class120 aClass120_1417;
	static Class120 aClass120_1418;
	public static Class120 aClass120_1419;
	public static Class120 aClass120_1420;
	public static Class120 aClass120_1421;
	static Class120 aClass120_1422;
	static Class120 aClass120_1423;
	public static Class120 aClass120_1424;
	public static Class120 aClass120_1425;
	static Class120 aClass120_1426;
	public static Class120 aClass120_1427;
	public static Class120 aClass120_1428 = new Class120(1);
	public static Class120 aClass120_1429;
	public static Class120 aClass120_1430;
	public static Class120 aClass120_1431;
	static Class120 aClass120_1432;
	static Class120 aClass120_1433;
	public static Class120 aClass120_1434;
	static Class120 aClass120_1435;
	public static Class120 aClass120_1436;
	public static Class120 aClass120_1437;
	public static Class120 aClass120_1438;
	public static Class120 aClass120_1439;
	public static Class120 aClass120_1440;
	public static Class120 aClass120_1441;
	static Class120 aClass120_1442;
	public static Class120 aClass120_1443;
	static Class120 aClass120_1444;
	static Class120 aClass120_1445;
	static Class120 aClass120_1446;
	static Class120 aClass120_1447;
	static Class120 aClass120_1448;
	public static Class120 aClass120_1449;
	static Class120 aClass120_1450;
	public static Class120 aClass120_1451;
	public static Class120 aClass120_1452;
	static Class120 aClass120_1453;
	static Class120 aClass120_1454;
	static Class120 aClass120_1455;
	static Class120 aClass120_1456;
	static Class120 aClass120_1457;
	static Class120 aClass120_1458;
	static Class120 aClass120_1459;
	public int anInt1460;
	int anInt1461;
	public static String aString1462;
	public static Class487 aClass487_1463;

	public int method1305(int i, int i_0_) {
		try {
			return i & (1 << ((Class120) this).anInt1461 * -82175751) - 1;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ew.b(").append(')').toString());
		}
	}

	Class120(int i, int i_1_) {
		anInt1460 = i * -1878339489;
		((Class120) this).anInt1461 = i_1_ * -1094244023;
	}

	public int method1306(short i) {
		try {
			return 1 << -82175751 * ((Class120) this).anInt1461;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ew.a(").append(')').toString());
		}
	}

	public int method1307(int i, int i_2_) {
		try {
			return i >>> -82175751 * ((Class120) this).anInt1461;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ew.f(").append(')').toString());
		}
	}

	static {
		aClass120_1415 = new Class120(2);
		aClass120_1425 = new Class120(3);
		aClass120_1439 = new Class120(4);
		aClass120_1427 = new Class120(5);
		aClass120_1443 = new Class120(6, 8);
		aClass120_1448 = new Class120(7);
		aClass120_1413 = new Class120(8, 8);
		aClass120_1410 = new Class120(9, 7);
		aClass120_1429 = new Class120(10, 8);
		aClass120_1416 = new Class120(11);
		aClass120_1409 = new Class120(12, 7);
		aClass120_1449 = new Class120(13, 8);
		aClass120_1406 = new Class120(14, 10);
		aClass120_1420 = new Class120(15);
		aClass120_1421 = new Class120(16);
		aClass120_1408 = new Class120(17);
		aClass120_1423 = new Class120(18);
		aClass120_1424 = new Class120(19);
		aClass120_1435 = new Class120(20);
		aClass120_1426 = new Class120(21);
		aClass120_1407 = new Class120(22);
		aClass120_1458 = new Class120(23);
		aClass120_1411 = new Class120(24);
		aClass120_1430 = new Class120(25);
		aClass120_1431 = new Class120(26);
		aClass120_1432 = new Class120(27);
		aClass120_1433 = new Class120(28);
		aClass120_1434 = new Class120(29);
		aClass120_1417 = new Class120(30);
		aClass120_1436 = new Class120(31);
		aClass120_1437 = new Class120(32);
		aClass120_1438 = new Class120(33);
		aClass120_1419 = new Class120(34);
		aClass120_1440 = new Class120(35);
		aClass120_1441 = new Class120(36);
		aClass120_1442 = new Class120(37);
		aClass120_1412 = new Class120(38);
		aClass120_1444 = new Class120(39);
		aClass120_1445 = new Class120(40);
		aClass120_1446 = new Class120(41);
		aClass120_1447 = new Class120(42);
		aClass120_1418 = new Class120(43);
		aClass120_1422 = new Class120(44);
		aClass120_1450 = new Class120(45);
		aClass120_1451 = new Class120(46);
		aClass120_1452 = new Class120(47);
		aClass120_1453 = new Class120(48);
		aClass120_1454 = new Class120(49);
		aClass120_1455 = new Class120(50);
		aClass120_1456 = new Class120(51);
		aClass120_1457 = new Class120(53);
		aClass120_1414 = new Class120(54);
		aClass120_1459 = new Class120(70);
	}

	Class120(int i) {
		this(i, 0);
	}

	public static String method1308(int i, byte i_3_) {
		try {
			Class298_Sub49 class298_sub49 = ((Class298_Sub49) Class423.aClass437_5354.method5812((long) i));
			if (class298_sub49 != null) {
				Class298_Sub24_Sub4 class298_sub24_sub4 = ((Class298_Sub49) class298_sub49).aClass308_Sub1_7591.method3772((byte) -78);
				if (null != class298_sub24_sub4) {
					double d = ((Class298_Sub49) class298_sub49).aClass308_Sub1_7591.method3779((short) 4615);
					if ((double) class298_sub24_sub4.method3092((byte) 8) <= d && ((double) class298_sub24_sub4.method3093(-327557193) >= d))
						return class298_sub24_sub4.method3094(-700699994);
				}
			}
			return null;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ew.i(").append(')').toString());
		}
	}

	static void method1309(byte i) {
		try {
			Class298_Sub9.aClass348_7223.method4187();
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ew.z(").append(')').toString());
		}
	}

	public static int method1310(String string, byte i) {
		try {
			return string.length() + 2;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ew.y(").append(')').toString());
		}
	}

	static void method1311(int i) {
		try {
			Class360.anInt3868 = -1058684408;
			Class360.aClass25_3905 = client.aClass25_8693;
			if (client.aByteArray8843 != null) {
				RsByteBuffer class298_sub53 = new RsByteBuffer(client.aByteArray8843);
				Class360.aLong3874 = (class298_sub53.readLong((short) 19840) * -2742373017286080113L);
				Class360.aLong3911 = (class298_sub53.readLong((short) 15472) * 3207425516430892907L);
			}
			if (122690138525332847L * Class360.aLong3874 < 0L)
				Class78.method845(35, 1176559477);
			else
				Class460.method5981(false, true, "", "", Class360.aLong3874 * 122690138525332847L);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ew.y(").append(')').toString());
		}
	}

	static float method1312(float f, float f_4_, float f_5_, float f_6_, float f_7_, float f_8_, int i, int i_9_) {
		try {
			float f_10_ = 0.0F;
			float f_11_ = f_6_ - f;
			float f_12_ = f_7_ - f_4_;
			float f_13_ = f_8_ - f_5_;
			float f_14_ = 0.0F;
			float f_15_ = 0.0F;
			float f_16_ = 0.0F;
			Class331 class331 = client.aClass283_8716.method2675(-1611682495);
			for (/**/; f_10_ < 1.1F; f_10_ += 0.1F) {
				float f_17_ = f_11_ * f_10_ + f;
				float f_18_ = f_4_ + f_10_ * f_12_;
				float f_19_ = f_10_ * f_13_ + f_5_;
				int i_20_ = (int) f_17_ >> 9;
				int i_21_ = (int) f_19_ >> 9;
				if (i_20_ > 0 && i_21_ > 0 && i_20_ < client.aClass283_8716.method2629(-1954958237) && i_21_ < client.aClass283_8716.method2630(-1173220944)) {
					int i_22_ = (Class287.myPlayer.plane);
					if (i_22_ < 3 && ((client.aClass283_8716.method2654(936952439).aByteArrayArrayArray2731[1][i_20_][i_21_]) & 0x2) != 0)
						i_22_++;
					int i_23_ = (class331.aClass_xaArray3519[i_22_].method6340((int) f_17_, (int) f_19_, -1328298083));
					if ((float) i_23_ < f_18_) {
						if (i >= 2)
							return (f_10_ - 0.1F + method1312(f_14_, f_15_, f_16_, f_17_, f_18_, f_19_, i - 1, 1869450178) * 0.1F);
						return f_10_;
					}
				}
				f_14_ = f_17_;
				f_15_ = f_18_;
				f_16_ = f_19_;
			}
			return -1.0F;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ew.bn(").append(')').toString());
		}
	}

	static final void method1313(ClientScript2 class403, int i) {
		try {
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub9_7555, (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]) == 1 ? 1 : 0, -1686668837);
			Class3.method300(656179282);
			client.aBoolean8666 = false;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ew.aio(").append(')').toString());
		}
	}
}
