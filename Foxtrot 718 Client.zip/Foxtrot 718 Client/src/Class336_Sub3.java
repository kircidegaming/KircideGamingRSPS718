/* Class336_Sub3 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class336_Sub3 extends Class336 {
	int anInt7715;

	public boolean method4089(int i, int i_0_, int i_1_, Class289 class289) {
		return class289.method2740(i_0_, i_1_, i, i, -1331662251 * toX, 1517720743 * toY, -1900284579 * sizeX, sizeY * 772610897, (((Class336_Sub3) this).anInt7715 * -1547195715), (byte) -126);
	}

	public boolean method4090(int i, int i_2_, int i_3_, Class289 class289, int i_4_) {
		try {
			return class289.method2740(i_2_, i_3_, i, i, -1331662251 * toX, 1517720743 * toY, -1900284579 * sizeX, sizeY * 772610897, (((Class336_Sub3) this).anInt7715 * -1547195715), (byte) -108);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("acg.a(").append(')').toString());
		}
	}

	public boolean method4091(int i, int i_5_, int i_6_, Class289 class289) {
		return class289.method2740(i_5_, i_6_, i, i, -1331662251 * toX, 1517720743 * toY, -1900284579 * sizeX, sizeY * 772610897, (((Class336_Sub3) this).anInt7715 * -1547195715), (byte) -11);
	}

	Class336_Sub3() {
		/* empty */
	}

	static final void method4098(ClientScript2 class403, byte i) {
		try {
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub16_7557.method5687(2118701003) == 1 ? 1 : 0;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("acg.akw(").append(')').toString());
		}
	}

	static final void method4099(ClientScript2 class403, int i) {
		try {
			Class390 class390 = (((ClientScript2) class403).aBoolean5261 ? ((ClientScript2) class403).aClass390_5247 : ((ClientScript2) class403).aClass390_5246);
			IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = -1993792969 * class105.anInt1223;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("acg.po(").append(')').toString());
		}
	}

	static final void method4100(ClientScript2 class403, int i) {
		try {
			int i_7_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			ClientScriptMap class483 = Class51.aClass475_506.getClientScriptMap(i_7_, 1528209569);
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = class483.method6129((byte) 77);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("acg.vc(").append(')').toString());
		}
	}

	static final void method4101(ClientScript2 class403, byte i) {
		try {
			Class242.anInt2709 = 0;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("acg.ada(").append(')').toString());
		}
	}

	static final void method4102(ClientScript2 class403, byte i) {
		try {
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = Class384.anInt4128 * -821031539;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("acg.amn(").append(')').toString());
		}
	}
}
