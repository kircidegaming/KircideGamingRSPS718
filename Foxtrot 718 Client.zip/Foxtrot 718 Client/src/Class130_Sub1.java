/* Class130_Sub1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public final class Class130_Sub1 extends Class130 {
	void method1463() {
		aClass_ra_Sub3_1495.method5357(0);
		aClass_ra_Sub3_1495.method5358(anInterface9_Impl2_1492);
		aClass_ra_Sub3_1495.method5296(0, Class183.aClass183_1888);
		aClass_ra_Sub3_1495.method5363(0, Class183.aClass183_1888);
		aClass_ra_Sub3_1495.method5361(Class175.aClass175_1765, Class175.aClass175_1765);
		aClass_ra_Sub3_1495.method5365().method2142(aClass233_1494);
		aClass_ra_Sub3_1495.method5366(Class171.aClass171_1741);
	}

	public void method1452(Class233 class233) {
		aClass_ra_Sub3_1495.method5300(class233, aClass_ra_Sub3_1495.aClass233_8230, aClass_ra_Sub3_1495.aClass233_8333);
	}

	public void method1450(int i) {
		aClass_ra_Sub3_1495.method5296(1, Class183.aClass183_1889);
		aClass_ra_Sub3_1495.method5363(1, Class183.aClass183_1889);
		method1463();
		aClass_ra_Sub3_1495.method5392(Class187.aClass187_1907, 0, i * 4, 0, i * 2);
	}

	public void method1451() {
		aClass_ra_Sub3_1495.method5414(anInt1493);
		aClass_ra_Sub3_1495.method5296(1, Class183.aClass183_1890);
		aClass_ra_Sub3_1495.method5363(1, Class183.aClass183_1890);
		method1463();
		aClass_ra_Sub3_1495.method5389();
	}

	public Class130_Sub1(Class_ra_Sub3 class_ra_sub3) {
		super(class_ra_sub3);
	}

	public void method1456(int i) {
		aClass_ra_Sub3_1495.method5296(1, Class183.aClass183_1889);
		aClass_ra_Sub3_1495.method5363(1, Class183.aClass183_1889);
		method1463();
		aClass_ra_Sub3_1495.method5392(Class187.aClass187_1907, 0, i * 4, 0, i * 2);
	}

	public void method1462() {
		aClass_ra_Sub3_1495.method5414(anInt1493);
		aClass_ra_Sub3_1495.method5296(1, Class183.aClass183_1890);
		aClass_ra_Sub3_1495.method5363(1, Class183.aClass183_1890);
		method1463();
		aClass_ra_Sub3_1495.method5389();
	}

	public void method1458(Class233 class233) {
		aClass_ra_Sub3_1495.method5300(class233, aClass_ra_Sub3_1495.aClass233_8230, aClass_ra_Sub3_1495.aClass233_8333);
	}

	public void method1461() {
		aClass_ra_Sub3_1495.method5414(anInt1493);
		aClass_ra_Sub3_1495.method5296(1, Class183.aClass183_1890);
		aClass_ra_Sub3_1495.method5363(1, Class183.aClass183_1890);
		method1463();
		aClass_ra_Sub3_1495.method5389();
	}

	public void method1448(Class233 class233) {
		aClass_ra_Sub3_1495.method5300(class233, aClass_ra_Sub3_1495.aClass233_8230, aClass_ra_Sub3_1495.aClass233_8333);
	}

	public void method1457(int i) {
		aClass_ra_Sub3_1495.method5296(1, Class183.aClass183_1889);
		aClass_ra_Sub3_1495.method5363(1, Class183.aClass183_1889);
		method1463();
		aClass_ra_Sub3_1495.method5392(Class187.aClass187_1907, 0, i * 4, 0, i * 2);
	}

	public void method1449(int i) {
		aClass_ra_Sub3_1495.method5296(1, Class183.aClass183_1889);
		aClass_ra_Sub3_1495.method5363(1, Class183.aClass183_1889);
		method1463();
		aClass_ra_Sub3_1495.method5392(Class187.aClass187_1907, 0, i * 4, 0, i * 2);
	}

	public void method1453(int i) {
		aClass_ra_Sub3_1495.method5296(1, Class183.aClass183_1889);
		aClass_ra_Sub3_1495.method5363(1, Class183.aClass183_1889);
		method1463();
		aClass_ra_Sub3_1495.method5392(Class187.aClass187_1907, 0, i * 4, 0, i * 2);
	}

	public void method1459() {
		aClass_ra_Sub3_1495.method5414(anInt1493);
		aClass_ra_Sub3_1495.method5296(1, Class183.aClass183_1890);
		aClass_ra_Sub3_1495.method5363(1, Class183.aClass183_1890);
		method1463();
		aClass_ra_Sub3_1495.method5389();
	}

	public void method1460() {
		aClass_ra_Sub3_1495.method5414(anInt1493);
		aClass_ra_Sub3_1495.method5296(1, Class183.aClass183_1890);
		aClass_ra_Sub3_1495.method5363(1, Class183.aClass183_1890);
		method1463();
		aClass_ra_Sub3_1495.method5389();
	}

	public void method1454(Class233 class233) {
		aClass_ra_Sub3_1495.method5300(class233, aClass_ra_Sub3_1495.aClass233_8230, aClass_ra_Sub3_1495.aClass233_8333);
	}

	public void method1455(Class233 class233) {
		aClass_ra_Sub3_1495.method5300(class233, aClass_ra_Sub3_1495.aClass233_8230, aClass_ra_Sub3_1495.aClass233_8333);
	}
}
