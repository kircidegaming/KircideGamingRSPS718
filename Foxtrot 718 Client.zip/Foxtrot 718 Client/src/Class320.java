/* Class320 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class320 implements Interface21 {
	public static Class320 aClass320_6547;
	static Class320 aClass320_6548 = new Class320(0);
	int anInt6549;
	public static Class494 aClass494_6550;

	Class320(int i) {
		((Class320) this).anInt6549 = -1849427999 * i;
	}

	public int method243() {
		return 2012122145 * ((Class320) this).anInt6549;
	}

	static {
		aClass320_6547 = new Class320(1);
	}

	public int method242(int i) {
		try {
			return 2012122145 * ((Class320) this).anInt6549;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ni.f(").append(')').toString());
		}
	}

	public int method244() {
		return 2012122145 * ((Class320) this).anInt6549;
	}

	public static void method3910(int i) {
		try {
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub17_7564, 1, -278860705);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub17_7565, 1, -1879075078);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub2_7547, 1, -144967877);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub28_7573, 1, 3979787);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub25_7569, 0, -1267983813);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub9_7555, 0, -479296878);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub18_7561, 0, 32404629);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub7_7581, 0, -1166259594);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub16_7557, 0, 221140911);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub15_7560, 0, 609592986);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub5_7572, 0, -1791107075);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub3_7556, 0, -240658138);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub13_7549, 0, 737950253);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub13_7550, 0, -1008071138);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub4_7563, 0, -1232122850);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub11_7558, -160182505 * Class115.aClass115_1383.anInt1387, 466531848);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub6_7551, 0, -1276228451);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub19_7567, 0, -23282776);
			Class490.method6170(1113089752);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub8_7566, 2, 1293702073);
			Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub23_7576, 2, 359344447);
			Class359.method4294(123459893);
			client.aClass283_8716.method2640((byte) -42).method4324(-1416696139);
			client.aBoolean8676 = true;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ni.x(").append(')').toString());
		}
	}

	static final void method3911(ClientScript2 class403, int i) {
		try {
			int i_0_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			IComponentDefinition class105 = Class50.getIComponentDefinitions(i_0_, (byte) -83);
			Class119 class119 = Class389.aClass119Array4165[i_0_ >> 16];
			Class257.method2451(class105, class119, class403, 505360650);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ni.ov(").append(')').toString());
		}
	}

	static final void method3912(ClientScript2 class403, int i) {
		try {
			int i_1_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub3_7556.method5612(i_1_, 1352882135);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ni.aoy(").append(')').toString());
		}
	}

	public static Class297 method3913(int i, int i_2_, int i_3_, int i_4_, boolean bool, int i_5_, int i_6_) {
		try {
			if ((bool ? Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub29_7583.method5726(-2146212397) : Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub29_7553.method5726(-2145707047)) != 0 && i_2_ != 0 && -991384187 * Class300.anInt3213 < 50 && i != -1) {
				Class297 class297 = new Class297(bool ? (byte) 3 : (byte) 2, i, i_2_, i_3_, i_4_, 0, i_5_, null);
				Class300.aClass297Array3214[(Class300.anInt3213 += -598588595) * -991384187 - 1] = class297;
				return class297;
			}
			return null;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ni.z(").append(')').toString());
		}
	}

	static Class516[] method3914(byte i) {
		try {
			return (new Class516[] { Class516.aClass516_6259, Class516.aClass516_6239, Class516.aClass516_6265, Class516.aClass516_6243, Class516.aClass516_6246, Class516.aClass516_6240, Class516.aClass516_6248, Class516.aClass516_6258, Class516.aClass516_6253, Class516.aClass516_6245, Class516.aClass516_6257, Class516.aClass516_6251, Class516.aClass516_6247, Class516.aClass516_6263, Class516.aClass516_6260, Class516.aClass516_6256, Class516.aClass516_6249, Class516.aClass516_6242, Class516.aClass516_6255, Class516.aClass516_6234, Class516.aClass516_6254, Class516.aClass516_6238, Class516.aClass516_6244, Class516.aClass516_6250, Class516.aClass516_6264, Class516.aClass516_6252, Class516.aClass516_6236, Class516.aClass516_6237, Class516.aClass516_6262, Class516.aClass516_6261, Class516.aClass516_6241 });
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ni.a(").append(')').toString());
		}
	}
}
