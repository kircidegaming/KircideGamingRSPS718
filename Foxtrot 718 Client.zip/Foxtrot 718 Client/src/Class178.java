/* Class178 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class178 {
	public static int anInt1790 = 3;
	public static int anInt1791 = 0;
	public static int anInt1792 = 24;
	public static int anInt1793 = 5;
	public static int anInt1794 = 4;
	public static int anInt1795 = 18;
	public static int anInt1796 = 6;
	public static int anInt1797 = 7;
	public static int anInt1798 = 20;
	public static int anInt1799 = 17;
	public static int anInt1800 = 98;
	public static int anInt1801 = 19;
	public static int anInt1802 = 1;
	public static int anInt1803 = 42;
	public static int anInt1804 = 25;
	public static int anInt1805 = 41;
	public static int anInt1806 = 9;
	public static int anInt1807 = 44;
	public static int anInt1808 = 45;
	public static int anInt1809 = 2;
	public static int anInt1810 = 99;

	Class178() throws Throwable {
		throw new Error();
	}

	static final void method1834(ClientScript2 class403, int i) {
		try {
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = Class514.aByte6228;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("hk.wb(").append(')').toString());
		}
	}

	static final void method1835(ClientScript2 class403, int i) {
		try {
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub29_7584.method5726(-2143935557);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("hk.ajx(").append(')').toString());
		}
	}
}
