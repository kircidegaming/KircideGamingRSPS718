/* Class227 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import java.awt.Rectangle;

public class Class227 {
	static Class227 aClass227_2530;
	static Class227 aClass227_2531;
	static Class227 aClass227_2532;
	static Class227 aClass227_2533;
	static Class227 aClass227_2534;
	static Class227 aClass227_2535;
	static Class227 aClass227_2536;
	static Class227 aClass227_2537;
	static Class227 aClass227_2538 = new Class227(0, Tradution.aClass470_5878, 2);
	static Class227 aClass227_2539;
	static Class227 aClass227_2540;
	static Class227 aClass227_2541;
	static Class227 aClass227_2542;
	Tradution aClass470_2543;
	static Class227 aClass227_2544;
	static Class227 aClass227_2545;
	static Class227 aClass227_2546;
	static Class227 aClass227_2547;
	public int anInt2548;
	Tradution aClass470_2549;
	boolean aBoolean2550;
	int anInt2551;
	int anInt2552;
	boolean aBoolean2553;
	static Class227 aClass227_2554;

	Class227(int i, Tradution class470, int i_0_) {
		this(i, class470, class470, i_0_, i_0_, true, false);
	}

	static Class227[] method2109(int i) {
		try {
			return (new Class227[] { aClass227_2538, aClass227_2531, aClass227_2532, aClass227_2533, aClass227_2534, aClass227_2535, aClass227_2536, aClass227_2539, aClass227_2541, aClass227_2530, aClass227_2537, aClass227_2540, aClass227_2542, aClass227_2554, aClass227_2544, aClass227_2545, aClass227_2546, aClass227_2547 });
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("jp.a(").append(')').toString());
		}
	}

	Class227(int i, Tradution class470, Tradution class470_1_, int i_2_, int i_3_) {
		this(i, class470, class470_1_, i_2_, i_3_, true, false);
	}

	Class227(int i, Tradution class470, Tradution class470_4_, int i_5_, int i_6_, boolean bool, boolean bool_7_) {
		anInt2548 = i * -1323079015;
		((Class227) this).aClass470_2549 = class470;
		((Class227) this).aClass470_2543 = class470_4_;
		((Class227) this).anInt2551 = i_5_ * -931220425;
		((Class227) this).anInt2552 = i_6_ * 774291301;
		((Class227) this).aBoolean2553 = bool;
		((Class227) this).aBoolean2550 = bool_7_;
	}

	static {
		aClass227_2531 = new Class227(1, Tradution.aClass470_5878, Tradution.aClass470_5878, 2, 3);
		aClass227_2532 = new Class227(2, Tradution.aClass470_5878, 3);
		aClass227_2533 = new Class227(3, Tradution.aClass470_5878, Tradution.aClass470_5878, 3, 4);
		aClass227_2534 = new Class227(4, Tradution.aClass470_5878, 4);
		aClass227_2535 = new Class227(5, Tradution.aClass470_5878, Tradution.aClass470_5878, 4, 5);
		aClass227_2536 = new Class227(6, Tradution.aClass470_5878, Tradution.aClass470_5878, 5, 98, true, true);
		aClass227_2539 = new Class227(7, Tradution.aClass470_5878, 99);
		aClass227_2541 = new Class227(8, Tradution.aClass470_5878, 100);
		aClass227_2530 = new Class227(9, Tradution.aClass470_5834, Tradution.aClass470_5834, 0, 92, true, true);
		aClass227_2537 = new Class227(10, Tradution.aClass470_5834, Tradution.aClass470_5834, 92, 93);
		aClass227_2540 = new Class227(11, Tradution.aClass470_5834, Tradution.aClass470_5834, 94, 95);
		aClass227_2542 = new Class227(12, Tradution.aClass470_5834, Tradution.aClass470_5834, 96, 97);
		aClass227_2554 = new Class227(13, Tradution.aClass470_5834, 97);
		aClass227_2544 = new Class227(14, Tradution.aClass470_5834, 97);
		aClass227_2545 = new Class227(15, Tradution.aClass470_5834, 100);
		aClass227_2546 = new Class227(16, Tradution.aClass470_5834, 100);
		aClass227_2547 = new Class227(17, Tradution.aClass470_5834, 100);
	}

	static final void method2110(ClientScript2 class403, byte i) {
		try {
			Class390 class390 = (((ClientScript2) class403).aBoolean5261 ? ((ClientScript2) class403).aClass390_5247 : ((ClientScript2) class403).aClass390_5246);
			IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
			Class119 class119 = ((Class390) class390).aClass119_4167;
			Class478.method6097(class105, class119, class403, 924787839);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("jp.ie(").append(')').toString());
		}
	}

	static final void method2111(ClientScript2 class403, int i) {
		try {
			((ClientScript2) class403).anInt5239 -= -783761378;
			int i_8_ = (((ClientScript2) class403).anIntArray5244[681479919 * ((ClientScript2) class403).anInt5239]);
			int i_9_ = (((ClientScript2) class403).anIntArray5244[1 + 681479919 * ((ClientScript2) class403).anInt5239]);
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = Class298_Sub1.method2845(i_8_, i_9_, true, false, 1482071907);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("jp.ub(").append(')').toString());
		}
	}

	static final void method2112(int i, int i_10_, int i_11_, int i_12_, byte i_13_) {
		try {
			for (int i_14_ = 0; i_14_ < client.anInt8686 * -112139815; i_14_++) {
				Rectangle rectangle = client.aRectangleArray8902[i_14_];
				if (rectangle.x + rectangle.width > i && rectangle.x < i + i_11_ && rectangle.height + rectangle.y > i_10_ && rectangle.y < i_12_ + i_10_)
					client.aBooleanArray8900[i_14_] = true;
			}
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("jp.kr(").append(')').toString());
		}
	}

	static final void method2113(ClientScript2 class403, int i) {
		try {
			int i_15_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			if (client.anInt8942 * 1131012101 == 2 && i_15_ < -1054937867 * client.anInt8941)
				((ClientScript2) class403).anObjectArray5240[((((ClientScript2) class403).anInt5241 += 969361751) * -203050393) - 1] = client.aStringArray8947[i_15_];
			else
				((ClientScript2) class403).anObjectArray5240[((((ClientScript2) class403).anInt5241 += 969361751) * -203050393) - 1] = "";
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("jp.wn(").append(')').toString());
		}
	}

	public static String method2114(CharSequence charsequence, int i) {
		try {
			String string = Class404.method4952(GraphicsToolkit.method5194(charsequence, (byte) -97));
			if (null == string)
				string = "";
			return string;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("jp.p(").append(')').toString());
		}
	}
}
