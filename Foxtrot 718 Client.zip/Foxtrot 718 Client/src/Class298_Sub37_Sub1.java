/* Class298_Sub37_Sub1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public abstract class Class298_Sub37_Sub1 extends Class298_Sub37 {
	Interface18 anInterface18_9575;
	int anInt9576;

	abstract Object method3406();

	abstract boolean method3407();

	abstract Object method3408();

	abstract boolean method3409();

	abstract Object method3410();

	Class298_Sub37_Sub1(Interface18 interface18, int i) {
		((Class298_Sub37_Sub1) this).anInterface18_9575 = interface18;
		((Class298_Sub37_Sub1) this).anInt9576 = i;
	}
}
