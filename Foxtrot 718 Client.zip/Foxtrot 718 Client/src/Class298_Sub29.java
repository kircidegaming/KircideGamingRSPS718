/* Class298_Sub29 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class298_Sub29 extends Class298 {
	public Object anObject7366;

	public Class298_Sub29(Object object) {
		anObject7366 = object;
	}

	static final void method3111(ClientScript2 class403, byte i) {
		try {
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = client.anInt8913 * -1710848853;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("abn.acb(").append(')').toString());
		}
	}
}
