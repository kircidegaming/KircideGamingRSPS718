/* Class294 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import java.awt.Component;

public class Class294 {
	public static int[] anIntArray3165;
	public static Interface_ma anInterface_ma3166;

	Class294() throws Throwable {
		throw new Error();
	}

	public static Class323 method2825(Component component, int i) {
		try {
			return new Class323_Sub1(component);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("mf.a(").append(')').toString());
		}
	}

	static final void method2826(ClientScript2 class403, int i) {
		try {
			((ClientScript2) class403).anInt5239 -= -1175642067;
			int i_0_ = (((ClientScript2) class403).anIntArray5244[((ClientScript2) class403).anInt5239 * 681479919]);
			int i_1_ = (((ClientScript2) class403).anIntArray5244[1 + 681479919 * ((ClientScript2) class403).anInt5239]);
			int i_2_ = (((ClientScript2) class403).anIntArray5244[2 + 681479919 * ((ClientScript2) class403).anInt5239]);
			Class301_Sub1.method3713(7, i_0_ << 16 | i_1_, i_2_, "", 768379136);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("mf.ala(").append(')').toString());
		}
	}
}
