/* Class298_Sub51_Sub3 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class298_Sub51_Sub3 extends Interface {
	Class409 aClass409_9778;

	public boolean method3573(int i) {
		try {
			Interface3 interface3 = ((Class298_Sub51_Sub3) this).aClass409_9778.method4971(136944619);
			if (null != interface3) {
				Class60.method709(Class502.aClass502_6730, interfaceId * -1617025021, -1, interface3, 2076264683);
				return true;
			}
			return false;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ajl.a(").append(')').toString());
		}
	}

	public Class298_Sub51_Sub3(int interfaceId, int clipped, Class409 class409) {
		super(interfaceId, clipped);
		((Class298_Sub51_Sub3) this).aClass409_9778 = class409;
	}

	public boolean method3579() {
		Interface3 interface3 = ((Class298_Sub51_Sub3) this).aClass409_9778.method4971(-1173830807);
		if (null != interface3) {
			Class60.method709(Class502.aClass502_6730, interfaceId * -1617025021, -1, interface3, 59069325);
			return true;
		}
		return false;
	}
}
