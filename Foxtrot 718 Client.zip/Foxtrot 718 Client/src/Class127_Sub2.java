/* Class127_Sub2 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class127_Sub2 extends Class127 {
	Class57 aClass57_8575;

	void method1414(boolean bool, int i, int i_0_) {
		int i_1_ = (method1418(-1625124707) * (-944287579 * ((Class127_Sub2) this).aClass128_6375.anInt6326) / 10000);
		int[] is = new int[4];
		Class373.aClass_ra4071.qa(is);
		Class373.aClass_ra4071.r(i, i_0_ + 2, i + i_1_, (((Class127_Sub2) this).aClass128_6375.anInt6330) * -1387457793 + i_0_);
		((Class127_Sub2) this).aClass57_8575.method636(i, 2 + i_0_, ((Class127_Sub2) this).aClass128_6375.anInt6326 * -944287579, -1387457793 * ((Class127_Sub2) this).aClass128_6375.anInt6330);
		Class373.aClass_ra4071.r(is[0], is[1], is[2], is[3]);
	}

	public void method53(int i) {
		try {
			super.method53(567803385);
			((Class127_Sub2) this).aClass57_8575 = Class422_Sub10.method5663((((Class127_Sub2) this).aClass243_6372), (((Class128_Sub1) (((Class127_Sub2) this).aClass128_6375)).anInt8553 * -1056757525), (byte) -76);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("zs.a(").append(')').toString());
		}
	}

	void method1411(boolean bool, int i, int i_2_, int i_3_) {
		try {
			int i_4_ = (method1418(1618885491) * (-944287579 * ((Class127_Sub2) this).aClass128_6375.anInt6326) / 10000);
			int[] is = new int[4];
			Class373.aClass_ra4071.qa(is);
			Class373.aClass_ra4071.r(i, i_2_ + 2, i + i_4_, (((Class127_Sub2) this).aClass128_6375.anInt6330) * -1387457793 + i_2_);
			((Class127_Sub2) this).aClass57_8575.method636(i, 2 + i_2_, ((Class127_Sub2) this).aClass128_6375.anInt6326 * -944287579, (-1387457793 * ((Class127_Sub2) this).aClass128_6375.anInt6330));
			Class373.aClass_ra4071.r(is[0], is[1], is[2], is[3]);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("zs.r(").append(')').toString());
		}
	}

	Class127_Sub2(CacheIndex class243, CacheIndex class243_5_, Class128_Sub1 class128_sub1) {
		super(class243, class243_5_, (Class128) class128_sub1);
	}

	public boolean method52(int i) {
		try {
			if (!super.method52(-1288443228))
				return false;
			return (((Class127_Sub2) this).aClass243_6372.method2310(-1056757525 * (((Class128_Sub1) ((Class127_Sub2) this).aClass128_6375).anInt8553), -457216440));
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("zs.b(").append(')').toString());
		}
	}

	void method1409(boolean bool, int i, int i_6_) {
		Class373.aClass_ra4071.method5019(i - 2, i_6_, ((Class127_Sub2) this).aClass128_6375.anInt6326 * -944287579 + 4, 2 + ((Class127_Sub2) this).aClass128_6375.anInt6330 * -1387457793, (((Class128_Sub1) ((Class127_Sub2) this).aClass128_6375).anInt8554 * 1514768717), 0);
		Class373.aClass_ra4071.method5019(i - 1, i_6_ + 1, ((Class127_Sub2) this).aClass128_6375.anInt6326 * -944287579 + 2, -1387457793 * ((Class127_Sub2) this).aClass128_6375.anInt6330, 0, 0);
	}

	public boolean method57() {
		if (!super.method52(-2146778663))
			return false;
		return (((Class127_Sub2) this).aClass243_6372.method2310(-1056757525 * (((Class128_Sub1) ((Class127_Sub2) this).aClass128_6375).anInt8553), -457216440));
	}

	public boolean method54() {
		if (!super.method52(1006079243))
			return false;
		return (((Class127_Sub2) this).aClass243_6372.method2310(-1056757525 * (((Class128_Sub1) ((Class127_Sub2) this).aClass128_6375).anInt8553), -457216440));
	}

	void method1412(boolean bool, int i, int i_7_, int i_8_) {
		try {
			Class373.aClass_ra4071.method5019(i - 2, i_7_, (((Class127_Sub2) this).aClass128_6375.anInt6326 * -944287579 + 4), 2 + (((Class127_Sub2) this).aClass128_6375.anInt6330 * -1387457793), (((Class128_Sub1) ((Class127_Sub2) this).aClass128_6375).anInt8554) * 1514768717, 0);
			Class373.aClass_ra4071.method5019(i - 1, i_7_ + 1, (((Class127_Sub2) this).aClass128_6375.anInt6326 * -944287579 + 2), -1387457793 * ((Class127_Sub2) this).aClass128_6375.anInt6330, 0, 0);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("zs.x(").append(')').toString());
		}
	}

	void method1413(boolean bool, int i, int i_9_) {
		int i_10_ = (method1418(1173142113) * (-944287579 * ((Class127_Sub2) this).aClass128_6375.anInt6326) / 10000);
		int[] is = new int[4];
		Class373.aClass_ra4071.qa(is);
		Class373.aClass_ra4071.r(i, i_9_ + 2, i + i_10_, (((Class127_Sub2) this).aClass128_6375.anInt6330) * -1387457793 + i_9_);
		((Class127_Sub2) this).aClass57_8575.method636(i, 2 + i_9_, ((Class127_Sub2) this).aClass128_6375.anInt6326 * -944287579, -1387457793 * ((Class127_Sub2) this).aClass128_6375.anInt6330);
		Class373.aClass_ra4071.r(is[0], is[1], is[2], is[3]);
	}

	public boolean method59() {
		if (!super.method52(1700813633))
			return false;
		return (((Class127_Sub2) this).aClass243_6372.method2310(-1056757525 * (((Class128_Sub1) ((Class127_Sub2) this).aClass128_6375).anInt8553), -457216440));
	}

	void method1415(boolean bool, int i, int i_11_) {
		int i_12_ = (method1418(1200646093) * (-944287579 * ((Class127_Sub2) this).aClass128_6375.anInt6326) / 10000);
		int[] is = new int[4];
		Class373.aClass_ra4071.qa(is);
		Class373.aClass_ra4071.r(i, i_11_ + 2, i + i_12_, (((Class127_Sub2) this).aClass128_6375.anInt6330) * -1387457793 + i_11_);
		((Class127_Sub2) this).aClass57_8575.method636(i, 2 + i_11_, ((Class127_Sub2) this).aClass128_6375.anInt6326 * -944287579, -1387457793 * ((Class127_Sub2) this).aClass128_6375.anInt6330);
		Class373.aClass_ra4071.r(is[0], is[1], is[2], is[3]);
	}

	void method1416(boolean bool, int i, int i_13_) {
		int i_14_ = (method1418(1506402112) * (-944287579 * ((Class127_Sub2) this).aClass128_6375.anInt6326) / 10000);
		int[] is = new int[4];
		Class373.aClass_ra4071.qa(is);
		Class373.aClass_ra4071.r(i, i_13_ + 2, i + i_14_, (((Class127_Sub2) this).aClass128_6375.anInt6330) * -1387457793 + i_13_);
		((Class127_Sub2) this).aClass57_8575.method636(i, 2 + i_13_, ((Class127_Sub2) this).aClass128_6375.anInt6326 * -944287579, -1387457793 * ((Class127_Sub2) this).aClass128_6375.anInt6330);
		Class373.aClass_ra4071.r(is[0], is[1], is[2], is[3]);
	}

	void method1410(boolean bool, int i, int i_15_) {
		Class373.aClass_ra4071.method5019(i - 2, i_15_, ((Class127_Sub2) this).aClass128_6375.anInt6326 * -944287579 + 4, 2 + ((Class127_Sub2) this).aClass128_6375.anInt6330 * -1387457793, (((Class128_Sub1) ((Class127_Sub2) this).aClass128_6375).anInt8554 * 1514768717), 0);
		Class373.aClass_ra4071.method5019(i - 1, i_15_ + 1, ((Class127_Sub2) this).aClass128_6375.anInt6326 * -944287579 + 2, -1387457793 * ((Class127_Sub2) this).aClass128_6375.anInt6330, 0, 0);
	}

	public void method55() {
		super.method53(-1809113492);
		((Class127_Sub2) this).aClass57_8575 = Class422_Sub10.method5663(((Class127_Sub2) this).aClass243_6372, (((Class128_Sub1) (((Class127_Sub2) this).aClass128_6375)).anInt8553 * -1056757525), (byte) -90);
	}

	void method1417(boolean bool, int i, int i_16_) {
		Class373.aClass_ra4071.method5019(i - 2, i_16_, ((Class127_Sub2) this).aClass128_6375.anInt6326 * -944287579 + 4, 2 + ((Class127_Sub2) this).aClass128_6375.anInt6330 * -1387457793, (((Class128_Sub1) ((Class127_Sub2) this).aClass128_6375).anInt8554 * 1514768717), 0);
		Class373.aClass_ra4071.method5019(i - 1, i_16_ + 1, ((Class127_Sub2) this).aClass128_6375.anInt6326 * -944287579 + 2, -1387457793 * ((Class127_Sub2) this).aClass128_6375.anInt6330, 0, 0);
	}
}
