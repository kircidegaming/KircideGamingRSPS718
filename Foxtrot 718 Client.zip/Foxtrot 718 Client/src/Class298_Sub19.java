/* Class298_Sub19 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public abstract class Class298_Sub19 extends Class298 {
	volatile boolean aBoolean7310 = true;
	int anInt7311;
	Class298_Sub26 aClass298_Sub26_7312;
	Class298_Sub19 aClass298_Sub19_7313;

	abstract void method2928(int[] is, int i, int i_0_);

	abstract int method2929();

	abstract Class298_Sub19 method2930();

	abstract Class298_Sub19 method2931();

	abstract void method2932(int[] is, int i, int i_1_);

	final void method2933(int[] is, int i, int i_2_) {
		if (((Class298_Sub19) this).aBoolean7310)
			method2934(is, i, i_2_);
		else
			method2935(i_2_);
	}

	abstract void method2934(int[] is, int i, int i_3_);

	abstract void method2935(int i);

	abstract int method2936();

	abstract Class298_Sub19 method2937();

	abstract Class298_Sub19 method2938();

	Class298_Sub19() {
		/* empty */
	}

	abstract Class298_Sub19 method2939();

	abstract Class298_Sub19 method2940();

	abstract Class298_Sub19 method2941();

	abstract int method2942();

	abstract int method2943();

	abstract Class298_Sub19 method2944();

	abstract void method2945(int[] is, int i, int i_4_);

	abstract Class298_Sub19 method2946();

	abstract void method2947(int i);

	abstract void method2948(int i);

	abstract void method2949(int i);

	int method2950() {
		return 255;
	}
}
