/* Class298_Sub11 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class298_Sub11 extends Class298 {
	int anInt7234;
	int anInt7235;
	Class298_Sub26_Sub1 aClass298_Sub26_Sub1_7236;
	int anInt7237;
	int anInt7238;
	int anInt7239;
	int anInt7240;
	int anInt7241;
	int anInt7242;
	int anInt7243;
	int anInt7244;
	int anInt7245;
	Class104 aClass104_7246;
	int anInt7247;
	int anInt7248;
	Class298_Sub34 aClass298_Sub34_7249;
	static int anInt7250 = 1048576;
	int anInt7251;
	Class298_Sub19_Sub2 aClass298_Sub19_Sub2_7252;
	int anInt7253;
	int anInt7254;
	int anInt7255;

	void method2902(byte i) {
		try {
			((Class298_Sub11) this).aClass298_Sub34_7249 = null;
			((Class298_Sub11) this).aClass298_Sub26_Sub1_7236 = null;
			((Class298_Sub11) this).aClass104_7246 = null;
			((Class298_Sub11) this).aClass298_Sub19_Sub2_7252 = null;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aaq.a(").append(')').toString());
		}
	}

	Class298_Sub11() {
		/* empty */
	}

	static final void method2903(ClientScript2 class403, byte i) {
		try {
			Class107.method1138(class403, -807637826);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("aaq.so(").append(')').toString());
		}
	}
}
