/* Class127_Sub3 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class127_Sub3 extends Class127 {
	void method1414(boolean bool, int i, int i_0_) {
		int i_1_ = (method1418(-580739090) * (-944287579 * ((Class127_Sub3) this).aClass128_6375.anInt6326) / 10000);
		Class373.aClass_ra4071.B(i, 2 + i_0_, i_1_, ((Class127_Sub3) this).aClass128_6375.anInt6330 * -1387457793 - 2, (((Class128_Sub2) ((Class127_Sub3) this).aClass128_6375).anInt8558 * 457840037), 0);
		Class373.aClass_ra4071.B(i + i_1_, 2 + i_0_, (((Class127_Sub3) this).aClass128_6375.anInt6326 * -944287579 - i_1_), ((Class127_Sub3) this).aClass128_6375.anInt6330 * -1387457793 - 2, 0, 0);
	}

	void method1411(boolean bool, int i, int i_2_, int i_3_) {
		try {
			int i_4_ = (method1418(-191128334) * (-944287579 * ((Class127_Sub3) this).aClass128_6375.anInt6326) / 10000);
			Class373.aClass_ra4071.B(i, 2 + i_2_, i_4_, (((Class127_Sub3) this).aClass128_6375.anInt6330) * -1387457793 - 2, (((Class128_Sub2) ((Class127_Sub3) this).aClass128_6375).anInt8558) * 457840037, 0);
			Class373.aClass_ra4071.B(i + i_4_, 2 + i_2_, (((Class127_Sub3) this).aClass128_6375.anInt6326) * -944287579 - i_4_, (((Class127_Sub3) this).aClass128_6375.anInt6330) * -1387457793 - 2, 0, 0);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("zu.r(").append(')').toString());
		}
	}

	Class127_Sub3(CacheIndex class243, CacheIndex class243_5_, Class128_Sub2 class128_sub2) {
		super(class243, class243_5_, (Class128) class128_sub2);
	}

	void method1413(boolean bool, int i, int i_6_) {
		int i_7_ = (method1418(1604037601) * (-944287579 * ((Class127_Sub3) this).aClass128_6375.anInt6326) / 10000);
		Class373.aClass_ra4071.B(i, 2 + i_6_, i_7_, ((Class127_Sub3) this).aClass128_6375.anInt6330 * -1387457793 - 2, (((Class128_Sub2) ((Class127_Sub3) this).aClass128_6375).anInt8558 * 457840037), 0);
		Class373.aClass_ra4071.B(i + i_7_, 2 + i_6_, (((Class127_Sub3) this).aClass128_6375.anInt6326 * -944287579 - i_7_), ((Class127_Sub3) this).aClass128_6375.anInt6330 * -1387457793 - 2, 0, 0);
	}

	void method1415(boolean bool, int i, int i_8_) {
		int i_9_ = (method1418(1183027095) * (-944287579 * ((Class127_Sub3) this).aClass128_6375.anInt6326) / 10000);
		Class373.aClass_ra4071.B(i, 2 + i_8_, i_9_, ((Class127_Sub3) this).aClass128_6375.anInt6330 * -1387457793 - 2, (((Class128_Sub2) ((Class127_Sub3) this).aClass128_6375).anInt8558 * 457840037), 0);
		Class373.aClass_ra4071.B(i + i_9_, 2 + i_8_, (((Class127_Sub3) this).aClass128_6375.anInt6326 * -944287579 - i_9_), ((Class127_Sub3) this).aClass128_6375.anInt6330 * -1387457793 - 2, 0, 0);
	}

	void method1416(boolean bool, int i, int i_10_) {
		int i_11_ = (method1418(1484742879) * (-944287579 * ((Class127_Sub3) this).aClass128_6375.anInt6326) / 10000);
		Class373.aClass_ra4071.B(i, 2 + i_10_, i_11_, ((Class127_Sub3) this).aClass128_6375.anInt6330 * -1387457793 - 2, (((Class128_Sub2) ((Class127_Sub3) this).aClass128_6375).anInt8558 * 457840037), 0);
		Class373.aClass_ra4071.B(i + i_11_, 2 + i_10_, (((Class127_Sub3) this).aClass128_6375.anInt6326 * -944287579 - i_11_), ((Class127_Sub3) this).aClass128_6375.anInt6330 * -1387457793 - 2, 0, 0);
	}

	void method1412(boolean bool, int i, int i_12_, int i_13_) {
		try {
			Class373.aClass_ra4071.method5019(i - 2, i_12_, (((Class127_Sub3) this).aClass128_6375.anInt6326 * -944287579 + 4), 2 + (-1387457793 * ((Class127_Sub3) this).aClass128_6375.anInt6330), -1393292711 * (((Class128_Sub2) ((Class127_Sub3) this).aClass128_6375).anInt8559), 0);
			Class373.aClass_ra4071.method5019(i - 1, 1 + i_12_, (((Class127_Sub3) this).aClass128_6375.anInt6326 * -944287579 + 2), -1387457793 * ((Class127_Sub3) this).aClass128_6375.anInt6330, 0, 0);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("zu.x(").append(')').toString());
		}
	}

	void method1410(boolean bool, int i, int i_14_) {
		Class373.aClass_ra4071.method5019(i - 2, i_14_, ((Class127_Sub3) this).aClass128_6375.anInt6326 * -944287579 + 4, 2 + -1387457793 * ((Class127_Sub3) this).aClass128_6375.anInt6330, -1393292711 * ((Class128_Sub2) ((Class127_Sub3) this).aClass128_6375).anInt8559, 0);
		Class373.aClass_ra4071.method5019(i - 1, 1 + i_14_, ((Class127_Sub3) this).aClass128_6375.anInt6326 * -944287579 + 2, -1387457793 * ((Class127_Sub3) this).aClass128_6375.anInt6330, 0, 0);
	}

	void method1409(boolean bool, int i, int i_15_) {
		Class373.aClass_ra4071.method5019(i - 2, i_15_, ((Class127_Sub3) this).aClass128_6375.anInt6326 * -944287579 + 4, 2 + -1387457793 * ((Class127_Sub3) this).aClass128_6375.anInt6330, -1393292711 * ((Class128_Sub2) ((Class127_Sub3) this).aClass128_6375).anInt8559, 0);
		Class373.aClass_ra4071.method5019(i - 1, 1 + i_15_, ((Class127_Sub3) this).aClass128_6375.anInt6326 * -944287579 + 2, -1387457793 * ((Class127_Sub3) this).aClass128_6375.anInt6330, 0, 0);
	}

	void method1417(boolean bool, int i, int i_16_) {
		Class373.aClass_ra4071.method5019(i - 2, i_16_, ((Class127_Sub3) this).aClass128_6375.anInt6326 * -944287579 + 4, 2 + -1387457793 * ((Class127_Sub3) this).aClass128_6375.anInt6330, -1393292711 * ((Class128_Sub2) ((Class127_Sub3) this).aClass128_6375).anInt8559, 0);
		Class373.aClass_ra4071.method5019(i - 1, 1 + i_16_, ((Class127_Sub3) this).aClass128_6375.anInt6326 * -944287579 + 2, -1387457793 * ((Class127_Sub3) this).aClass128_6375.anInt6330, 0, 0);
	}

	static int method1431(RsBitsBuffer class298_sub53_sub2, int i) {
		try {
			int i_17_ = class298_sub53_sub2.readBits(2);
			int i_18_;
			if (0 == i_17_)
				i_18_ = 0;
			else if (i_17_ == 1)
				i_18_ = class298_sub53_sub2.readBits(5);
			else if (i_17_ == 2)
				i_18_ = class298_sub53_sub2.readBits(8);
			else
				i_18_ = class298_sub53_sub2.readBits(11);
			return i_18_;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("zu.p(").append(')').toString());
		}
	}

	static final void method1432(ClientScript2 class403, int i) {
		try {
			int i_19_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			String string = (String) (((ClientScript2) class403).anObjectArray5240[(((ClientScript2) class403).anInt5241 -= 969361751) * -203050393]);
			if (-1 == i_19_)
				throw new RuntimeException();
			ClientScriptMap class483 = Class51.aClass475_506.getClientScriptMap(i_19_, 1528209569);
			if (class483.aChar6037 != 's')
				throw new RuntimeException();
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = class483.method6127(string, (byte) 88) ? 1 : 0;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("zu.va(").append(')').toString());
		}
	}

	static final void method1433(ClientScript2 class403, byte i) {
		try {
			((ClientScript2) class403).anInt5245 -= -1365138610;
			if ((((ClientScript2) class403).aLongArray5251[((ClientScript2) class403).anInt5245 * 1685767703]) >= (((ClientScript2) class403).aLongArray5251[1685767703 * ((ClientScript2) class403).anInt5245 + 1]))
				((ClientScript2) class403).integerPos += (286750741 * (((ClientScript2) class403).integerstack[((ClientScript2) class403).integerPos * 1883543357]));
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("zu.bu(").append(')').toString());
		}
	}

	public static void method1434(int i) {
		try {
			Class300.aClass297Array3214 = new Class297[50];
			Class300.anInt3213 = 0;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("zu.u(").append(')').toString());
		}
	}
}
