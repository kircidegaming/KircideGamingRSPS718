/* Class298_Sub54 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class298_Sub54 extends Class298 {
	byte[] aByteArray7620;
	int[] anIntArray7621;

	Class298_Sub54(int[] is, byte[] is_0_) {
		((Class298_Sub54) this).anIntArray7621 = is;
		((Class298_Sub54) this).aByteArray7620 = is_0_;
	}
}
