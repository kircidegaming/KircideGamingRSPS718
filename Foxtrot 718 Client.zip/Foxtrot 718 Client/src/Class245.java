/* Class245 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import jaggl.OpenGL;

public class Class245 implements Interface8_Impl1_Impl1_Impl3 {
	int anInt10174;
	Class263_Sub1 aClass263_Sub1_10175;

	public void method168(int i) {
		OpenGL.glFramebufferTexture2DEXT(36160, i, (((Class263_Sub1) ((Class245) this).aClass263_Sub1_10175).anInt6415), (((Class263_Sub1) ((Class245) this).aClass263_Sub1_10175).anInt6417), ((Class245) this).anInt10174);
	}

	public int i() {
		return ((Class245) this).aClass263_Sub1_10175.method92();
	}

	public int f() {
		return ((Class245) this).aClass263_Sub1_10175.method76();
	}

	public void method167(int i) {
		OpenGL.glFramebufferTexture2DEXT(36160, i, (((Class263_Sub1) ((Class245) this).aClass263_Sub1_10175).anInt6415), (((Class263_Sub1) ((Class245) this).aClass263_Sub1_10175).anInt6417), ((Class245) this).anInt10174);
	}

	public void b() {
		/* empty */
	}

	Class245(Class263_Sub1 class263_sub1, int i) {
		((Class245) this).anInt10174 = i;
		((Class245) this).aClass263_Sub1_10175 = class263_sub1;
	}

	public int a() {
		return ((Class245) this).aClass263_Sub1_10175.method92();
	}

	public int k() {
		return ((Class245) this).aClass263_Sub1_10175.method76();
	}

	public void d() {
		/* empty */
	}

	public void u() {
		/* empty */
	}

	public void x() {
		/* empty */
	}

	public void method165(int i) {
		OpenGL.glFramebufferTexture2DEXT(36160, i, (((Class263_Sub1) ((Class245) this).aClass263_Sub1_10175).anInt6415), (((Class263_Sub1) ((Class245) this).aClass263_Sub1_10175).anInt6417), ((Class245) this).anInt10174);
	}

	public void method166(int i) {
		OpenGL.glFramebufferTexture2DEXT(36160, i, (((Class263_Sub1) ((Class245) this).aClass263_Sub1_10175).anInt6415), (((Class263_Sub1) ((Class245) this).aClass263_Sub1_10175).anInt6417), ((Class245) this).anInt10174);
	}

	public void method164(int i) {
		OpenGL.glFramebufferTexture2DEXT(36160, i, (((Class263_Sub1) ((Class245) this).aClass263_Sub1_10175).anInt6415), (((Class263_Sub1) ((Class245) this).aClass263_Sub1_10175).anInt6417), ((Class245) this).anInt10174);
	}

	public int p() {
		return ((Class245) this).aClass263_Sub1_10175.method92();
	}
}
