/* Class298_Sub43 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public final class Class298_Sub43 extends Class298 implements Interface16 {
	static int anInt6505 = -1;//TODO
	int anInt6506;
	int anInt6507;
	int anInt6508;
	long aLong6509;
	char aChar6510;

	public int method225() {
		return 122236875 * ((Class298_Sub43) this).anInt6508;
	}

	public int method227(int i) {
		try {
			return ((Class298_Sub43) this).anInt6506 * 1490207653;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("acb.a(").append(')').toString());
		}
	}

	public char method217(byte i) {
		try {
			return ((Class298_Sub43) this).aChar6510;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("acb.f(").append(')').toString());
		}
	}

	public int method218(byte i) {
		try {
			return 122236875 * ((Class298_Sub43) this).anInt6508;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("acb.b(").append(')').toString());
		}
	}

	public long method216(int i) {
		try {
			return 4761371342045314899L * ((Class298_Sub43) this).aLong6509;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("acb.p(").append(')').toString());
		}
	}

	public int method220(byte i) {
		try {
			return 1312925659 * ((Class298_Sub43) this).anInt6507;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("acb.i(").append(')').toString());
		}
	}

	public int method221() {
		return ((Class298_Sub43) this).anInt6506 * 1490207653;
	}

	public char method219() {
		return ((Class298_Sub43) this).aChar6510;
	}

	public char method223() {
		return ((Class298_Sub43) this).aChar6510;
	}

	public int method222() {
		return 122236875 * ((Class298_Sub43) this).anInt6508;
	}

	public long method226() {
		return 4761371342045314899L * ((Class298_Sub43) this).aLong6509;
	}

	Class298_Sub43() {
		/* empty */
	}

	public int method224() {
		return 1312925659 * ((Class298_Sub43) this).anInt6507;
	}

	static final void method3525(ClientScript2 class403, int i) {
		try {
			int i_0_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 += -391880689) * 681479919 - 1)] = client.anIntArray8924[i_0_];
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("acb.ti(").append(')').toString());
		}
	}

	static final void method3526(ClientScript2 class403, int i) {
		try {
			int i_1_ = (((ClientScript2) class403).anIntArray5244[((((ClientScript2) class403).anInt5239 -= -391880689) * 681479919)]);
			IComponentDefinition class105 = Class50.getIComponentDefinitions(i_1_, (byte) -13);
			Class119 class119 = Class389.aClass119Array4165[i_1_ >> 16];
			Class365_Sub1.method4401(class105, class119, class403, (byte) -6);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("acb.iq(").append(')').toString());
		}
	}

	static final void method3527(IComponentDefinition class105, Class119 class119, ClientScript2 class403, byte i) {
		try {
			class105.anInt1210 = (((ClientScript2) class403).anIntArray5244[(((ClientScript2) class403).anInt5239 -= -391880689) * 681479919]) * -2074006897;
			Tradution.method6054(class105, -542693615);
			if (-1 == class105.anInt1154 * -1309843523 && !class119.aBoolean1403)
				Class82_Sub20.method934(class105.anInt1142 * -440872681, (byte) 7);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("acb.ez(").append(')').toString());
		}
	}
}
