/* Class153 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public abstract class Class153 implements Interface8 {
	public Class181[] aClass181Array6405;

	Class153(Class181[] class181s) {
		aClass181Array6405 = class181s;
	}
}
