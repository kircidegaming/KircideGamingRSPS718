/* Class192 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import jagdx.IDirect3DTexture;
import jagdx.IUnknown;

public class Class192 implements Interface8_Impl1_Impl1_Impl1, Interface8_Impl1_Impl2_Impl1 {
	long aLong10166;
	Class200_Sub3_Sub1 aClass200_Sub3_Sub1_10167;
	int anInt10168;

	public void method143() {
		if (((Class192) this).aLong10166 != 0L) {
			((Class200_Sub3_Sub1) ((Class192) this).aClass200_Sub3_Sub1_10167).aClass_ra_Sub3_Sub2_6410.method5552(((Class192) this).aLong10166);
			((Class192) this).aLong10166 = 0L;
		}
	}

	public int a() {
		return ((Class192) this).aClass200_Sub3_Sub1_10167.method92();
	}

	public int f() {
		return ((Class192) this).aClass200_Sub3_Sub1_10167.method76();
	}

	public long method144() {
		if (((Class192) this).aLong10166 == 0L)
			((Class192) this).aLong10166 = (IDirect3DTexture.GetSurfaceLevel(((Class200_Sub3_Sub1) ((Class192) this).aClass200_Sub3_Sub1_10167).aLong6407, ((Class192) this).anInt10168));
		return ((Class192) this).aLong10166;
	}

	public void b() {
		if (((Class192) this).aLong10166 != 0L) {
			IUnknown.Release(((Class192) this).aLong10166);
			((Class192) this).aLong10166 = 0L;
		}
		((Class200_Sub3_Sub1) ((Class192) this).aClass200_Sub3_Sub1_10167).aClass_ra_Sub3_Sub2_6410.method5293(this);
	}

	public void method141() {
		if (((Class192) this).aLong10166 != 0L) {
			((Class200_Sub3_Sub1) ((Class192) this).aClass200_Sub3_Sub1_10167).aClass_ra_Sub3_Sub2_6410.method5552(((Class192) this).aLong10166);
			((Class192) this).aLong10166 = 0L;
		}
	}

	public int k() {
		return ((Class192) this).aClass200_Sub3_Sub1_10167.method76();
	}

	public long method145() {
		if (((Class192) this).aLong10166 == 0L)
			((Class192) this).aLong10166 = (IDirect3DTexture.GetSurfaceLevel(((Class200_Sub3_Sub1) ((Class192) this).aClass200_Sub3_Sub1_10167).aLong6407, ((Class192) this).anInt10168));
		return ((Class192) this).aLong10166;
	}

	public void u() {
		if (((Class192) this).aLong10166 != 0L) {
			IUnknown.Release(((Class192) this).aLong10166);
			((Class192) this).aLong10166 = 0L;
		}
		((Class200_Sub3_Sub1) ((Class192) this).aClass200_Sub3_Sub1_10167).aClass_ra_Sub3_Sub2_6410.method5293(this);
	}

	public void x() {
		if (((Class192) this).aLong10166 != 0L) {
			IUnknown.Release(((Class192) this).aLong10166);
			((Class192) this).aLong10166 = 0L;
		}
		((Class200_Sub3_Sub1) ((Class192) this).aClass200_Sub3_Sub1_10167).aClass_ra_Sub3_Sub2_6410.method5293(this);
	}

	public int p() {
		return ((Class192) this).aClass200_Sub3_Sub1_10167.method92();
	}

	public int i() {
		return ((Class192) this).aClass200_Sub3_Sub1_10167.method92();
	}

	public long method147() {
		if (((Class192) this).aLong10166 == 0L)
			((Class192) this).aLong10166 = (IDirect3DTexture.GetSurfaceLevel(((Class200_Sub3_Sub1) ((Class192) this).aClass200_Sub3_Sub1_10167).aLong6407, ((Class192) this).anInt10168));
		return ((Class192) this).aLong10166;
	}

	Class192(Class200_Sub3_Sub1 class200_sub3_sub1, int i) {
		((Class192) this).anInt10168 = i;
		((Class192) this).aClass200_Sub3_Sub1_10167 = class200_sub3_sub1;
		((Class200_Sub3_Sub1) ((Class192) this).aClass200_Sub3_Sub1_10167).aClass_ra_Sub3_Sub2_6410.method5323(this);
	}

	public void method146() {
		if (((Class192) this).aLong10166 != 0L) {
			((Class200_Sub3_Sub1) ((Class192) this).aClass200_Sub3_Sub1_10167).aClass_ra_Sub3_Sub2_6410.method5552(((Class192) this).aLong10166);
			((Class192) this).aLong10166 = 0L;
		}
	}

	public void d() {
		if (((Class192) this).aLong10166 != 0L) {
			IUnknown.Release(((Class192) this).aLong10166);
			((Class192) this).aLong10166 = 0L;
		}
		((Class200_Sub3_Sub1) ((Class192) this).aClass200_Sub3_Sub1_10167).aClass_ra_Sub3_Sub2_6410.method5293(this);
	}

	public void method142() {
		if (((Class192) this).aLong10166 != 0L) {
			((Class200_Sub3_Sub1) ((Class192) this).aClass200_Sub3_Sub1_10167).aClass_ra_Sub3_Sub2_6410.method5552(((Class192) this).aLong10166);
			((Class192) this).aLong10166 = 0L;
		}
	}

	public void method148() {
		if (((Class192) this).aLong10166 != 0L) {
			((Class200_Sub3_Sub1) ((Class192) this).aClass200_Sub3_Sub1_10167).aClass_ra_Sub3_Sub2_6410.method5552(((Class192) this).aLong10166);
			((Class192) this).aLong10166 = 0L;
		}
	}
}
