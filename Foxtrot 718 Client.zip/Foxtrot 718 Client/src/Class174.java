/* Class174 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class174 {
	public static Class174 aClass174_1760;
	public static Class174 aClass174_1761;
	public static Class174 aClass174_1762;
	static Class174 aClass174_1763 = new Class174(3);
	public int anInt1764;

	static {
		aClass174_1760 = new Class174(1);
		aClass174_1761 = new Class174(2);
		aClass174_1762 = new Class174(0);
	}

	Class174(int i) {
		anInt1764 = i;
	}
}
