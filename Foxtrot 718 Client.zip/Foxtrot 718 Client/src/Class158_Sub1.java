/* Class158_Sub1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class158_Sub1 extends Class158 {
	public int anInt8567;
	public static Class389 aClass389_8568;

	public Class146 method49(int i) {
		try {
			return Class146.aClass146_1573;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("zk.f(").append(')').toString());
		}
	}

	public Class146 method50() {
		return Class146.aClass146_1573;
	}

	Class158_Sub1(int i, Class139 class139, Class133 class133, int i_0_, int i_1_, int i_2_) {
		super(i, class139, class133, i_0_, i_1_);
		anInt8567 = -899365323 * i_2_;
	}

	public Class146 method51() {
		return Class146.aClass146_1573;
	}

	static boolean method1703(int i, int i_3_) {
		try {
			return 19 == i || 4 == i || 3 == i || 8 == i || i == 2 || i == 9;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("zk.fi(").append(')').toString());
		}
	}
}
