/* Annotation_Impl1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import java.lang.annotation.Annotation;

public interface Annotation_Impl1 extends Annotation {
}
