/* Class298_Sub22 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public abstract class Class298_Sub22 extends Class298 {
	int anInt7316;

	abstract int method3054(Class298_Sub19_Sub4 class298_sub19_sub4);

	abstract void method3055();

	abstract int method3056(Class298_Sub19_Sub4 class298_sub19_sub4);

	abstract void method3057();

	Class298_Sub22() throws Throwable {
		throw new Error();
	}

	abstract void method3058();

	abstract int method3059(Class298_Sub19_Sub4 class298_sub19_sub4);

	abstract void method3060();
}
